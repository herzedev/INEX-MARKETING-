# Unex Marketplace - Application Mobile E-commerce & Grossiste Madagascar

**Unex** est une application marketplace moderne pour acheteurs et vendeurs à Madagascar, inspirée des fonctionnalités d'Alibaba (vente au détail et en gros avec remises sur volume), adaptée au marché malgache avec la monnaie **Ariary (MGA)**, les adresses locales et les solutions de paiement mobiles.

---

## 🚀 1. Lancement et Test en Développement

### Prérequis
- Node.js (version 18 ou supérieure)
- npm

### Commandes d'installation et de démarrage
```bash
# Installer les dépendances
npm install

# Démarrer le serveur de développement local
npm run dev

# Tester la compilation de production
npm run build
```
L'application se lance sur `http://localhost:3000`.

---

## 📱 2. Comment générer le fichier APK Android installable

Pour produire un véritable fichier `.apk` installable sur n'importe quel téléphone Android :

### Étape 1 : Installer le framework natif Capacitor
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
```

### Étape 2 : Initialiser le projet Android
```bash
npx cap init Unex com.unex.marketplace --web-dir dist
```

### Étape 3 : Compiler l'application et synchroniser avec Android
```bash
npm run build
npx cap add android
npx cap sync android
```

### Étape 4 : Ouvrir dans Android Studio et compiler l'APK
```bash
npx cap open android
```
Dans Android Studio :
1. Attendez que le Gradle Sync se termine.
2. Cliquez sur le menu supérieur : **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
3. Le fichier APK sera généré dans :
   `android/app/build/outputs/apk/debug/app-debug.apk`

### Étape 5 : Installer sur un smartphone Android
- Transférez `app-debug.apk` sur votre téléphone via câble USB, WhatsApp ou Google Drive.
- Sur le téléphone, appuyez sur le fichier et autorisez « Installer des applications inconnues ».
- L'application **Unex** est installée avec son icône sur votre écran d'accueil !

---

## 🔒 3. Architecture Firebase & Sécurité

L'application intègre une architecture modulaire prête pour Firebase :

- **`firestore.rules`** : Règles de sécurité Firestore avec RBAC (clients, vendeurs, administrateurs), validation des prix positifs, contrôle des stocks et vérification d'appartenance des commandes.
- **`storage.rules`** : Règles Firebase Storage pour le téléversement d'images produits (max 10 Mo) et avatars.
- **`firebase-blueprint.json`** : Schéma complet des collections Firestore (`users`, `products`, `orders`, `conversations`).
- **Mode Hybride** : L'application fonctionne immédiatement en mode démonstration réactif avec persistance locale, et bascule automatiquement sur votre projet Firebase réel dès que vous renseignez vos identifiants dans l'interface ou dans `.env`.

---

## 📊 4. État des fonctionnalités

| Fonctionnalité | Statut | Note |
|---|---|---|
| Catalogue & Grille de produits | ✅ 100% Fonctionnel | Image, titre, prix MGA, palier de gros, vendeur, avis |
| Recherche & Filtres avancés | ✅ 100% Fonctionnel | Recherche textuelle, filtre prix slider, stock, villes de Mada |
| Multilingue (FR, Malagasy, EN) | ✅ 100% Fonctionnel | Changement instantané avec dictionnaire complet |
| Panier & Remises de gros | ✅ 100% Fonctionnel | Calcul automatique des paliers de gros (ex: dès 3 pcs) |
| Processus de commande | ✅ 100% Fonctionnel | Formulaire avec villes de Mada, vérification de stock, confetti |
| Espace Vendeur | ✅ 100% Fonctionnel | Ajout/modification de produit, stock en direct, commandes reçues |
| Espace Administrateur | ✅ 100% Fonctionnel | Modération, statistiques de vente GMV, suspension de comptes |
| Contact Vendeur (WhatsApp) | ✅ 100% Fonctionnel | Ouvre directement WhatsApp avec message prérempli |
| Messagerie interne Unex | ✅ 100% Fonctionnel | Chat en direct acheteur/vendeur avec référence de l'article |
| Paiement Mobile Money réel | ⚙️ Prêt à connecter | Enregistre le choix (MVola/Orange/Airtel) ; nécessite les clés API marchands Telma/Orange |
| Cloud Firebase en ligne | ⚙️ Prêt à connecter | Règles et schéma prêts ; activez votre projet via l'écran Firebase de l'appli |

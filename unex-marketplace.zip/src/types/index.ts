export type UserRole = 'buyer' | 'seller' | 'admin';

export type Language = 'fr' | 'mg' | 'en';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  whatsapp?: string;
  role: UserRole;
  avatar?: string;
  city: string;
  address?: string;
  shopName?: string;
  shopDescription?: string;
  shopLogo?: string;
  isVerifiedSeller?: boolean;
  isSuspended?: boolean;
  createdAt: string;
}

export type ProductCategory =
  | 'vetements'
  | 'telephones'
  | 'informatique'
  | 'accessoires'
  | 'maison'
  | 'beaute'
  | 'agriculture'
  | 'autres';

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number; // in MGA (Ariary)
  wholesalePrice?: number; // Wholesale price for bulk orders (inspired by Alibaba)
  minWholesaleQty?: number;
  category: ProductCategory;
  images: string[];
  stock: number;
  deliveryFee: number; // in MGA
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  sellerWhatsapp?: string;
  sellerCity: string;
  rating: number;
  reviewsCount: number;
  status: 'active' | 'pending' | 'rejected';
  featured?: boolean;
  createdAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type OrderStatus =
  | 'pending'    // En attente
  | 'confirmed'  // Confirmée par le vendeur
  | 'shipped'    // Expédiée / En cours de livraison
  | 'delivered'  // Livrée
  | 'cancelled'; // Annulée

export interface OrderItem {
  productId: string;
  title: string;
  price: number;
  quantity: number;
  image: string;
  sellerId: string;
}

export interface Order {
  id: string;
  buyerId: string;
  buyerName: string;
  buyerPhone: string;
  buyerCity: string;
  deliveryAddress: string;
  notes?: string;
  items: OrderItem[];
  totalAmount: number;
  deliveryFee: number;
  paymentMethod: 'cod' | 'mvola' | 'orange_money' | 'airtel_money';
  status: OrderStatus;
  sellerIds: string[];
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  text: string;
  productId?: string;
  productTitle?: string;
  productPrice?: number;
  productImage?: string;
  timestamp: string;
  read: boolean;
}

export interface Conversation {
  id: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  sellerName: string;
  lastMessage: string;
  lastTimestamp: string;
  productId?: string;
  productTitle?: string;
  productImage?: string;
  unreadCountBuyer: number;
  unreadCountSeller: number;
}

export interface FirebaseSettings {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
  isConnected: boolean;
}

import React, { useState } from 'react';
import {
  Sparkles,
  Layers,
  ArrowRight,
  TrendingUp,
  Package,
  Heart,
  SlidersHorizontal,
  RotateCcw,
  Store,
  Shield,
  Smartphone,
  ChevronRight,
  Shirt,
  Laptop,
  Watch,
  Home as HomeIcon,
  Sprout,
  Grid as GridIcon
} from 'lucide-react';
import { LanguageProvider, useLanguage } from './i18n/LanguageContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider, useCart } from './context/CartContext';
import { MarketProvider, useMarket } from './context/MarketContext';
import { Header } from './components/layout/Header';
import { BottomNav, NavTab } from './components/layout/BottomNav';
import { AndroidFrame } from './components/layout/AndroidFrame';
import { ProductCard } from './components/product/ProductCard';
import { ProductDetailModal } from './components/product/ProductDetailModal';
import { ProductFilterModal } from './components/product/ProductFilterModal';
import { CartDrawer } from './components/cart/CartDrawer';
import { CheckoutModal } from './components/cart/CheckoutModal';
import { OrderHistoryModal } from './components/orders/OrderHistoryModal';
import { SellerDashboard } from './components/seller/SellerDashboard';
import { AdminPanelModal } from './components/admin/AdminPanelModal';
import { AuthModal } from './components/auth/AuthModal';
import { ChatModal } from './components/chat/ChatModal';
import { FirebaseConfigModal } from './components/guide/FirebaseConfigModal';
import { AndroidApkGuideModal } from './components/guide/AndroidApkGuideModal';
import { CATEGORIES } from './i18n/translations';
import { CartItem, Product, ProductCategory } from './types';

const categoryIconMap: Record<string, React.ElementType> = {
  Shirt: Shirt,
  Smartphone: Smartphone,
  Laptop: Laptop,
  Watch: Watch,
  Home: HomeIcon,
  Sparkles: Sparkles,
  Sprout: Sprout,
  Grid: GridIcon
};

function MarketplaceContent() {
  const { t, language, formatMGA } = useLanguage();
  const { currentUser } = useAuth();
  const { cart, favorites } = useCart();
  const {
    filteredProducts,
    filters,
    setFilters,
    resetFilters,
    selectedProductForDetail,
    setSelectedProductForDetail,
    openChat
  } = useMarket();

  // Navigation & Modal states
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [directCheckoutItem, setDirectCheckoutItem] = useState<CartItem | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isFirebaseOpen, setIsFirebaseOpen] = useState(false);
  const [isApkGuideOpen, setIsApkGuideOpen] = useState(false);

  // Android device simulator frame toggle
  const [isFrameMode, setIsFrameMode] = useState(false);

  const handleDirectCheckout = (product: Product, quantity: number) => {
    setDirectCheckoutItem({ product, quantity });
    setIsCheckoutOpen(true);
  };

  const handleCategoryClick = (catId: ProductCategory) => {
    setFilters(prev => ({
      ...prev,
      category: prev.category === catId ? 'all' : catId
    }));
    setActiveTab('home');
  };

  return (
    <AndroidFrame
      isFrameMode={isFrameMode}
      onToggleFrame={() => setIsFrameMode(prev => !prev)}
    >
      {/* Sticky Header with Search, Language, Cart, and Mode switcher */}
      <Header
        onOpenFilter={() => setIsFilterOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenFirebaseConfig={() => setIsFirebaseOpen(true)}
        onOpenApkGuide={() => setIsApkGuideOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 pb-4">
        {/* TAB 1: HOME */}
        {activeTab === 'home' && (
          <div className="space-y-4">
            {/* Promo Marketplace Hero Banner (inspired by Alibaba wholesale & retail) */}
            <div className="px-3.5 pt-3">
              <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-slate-800 to-orange-950 p-4 text-white overflow-hidden shadow-xl border border-slate-800">
                <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-orange-500/20 rounded-full blur-2xl"></div>
                <div className="relative z-10 space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-orange-500 text-white text-[10px] font-black uppercase tracking-wider">
                    <Layers className="w-3 h-3" />
                    <span>Marché Gros & Détail Mada</span>
                  </div>
                  <h2 className="text-base font-extrabold tracking-tight leading-snug max-w-[260px]">
                    Achetez directement aux producteurs & importateurs
                  </h2>
                  <p className="text-[11px] text-slate-300 max-w-[280px]">
                    Prix en Ariary (MGA), remises par volume, livraison rapide à Antananarivo et provinces.
                  </p>
                </div>
              </div>
            </div>

            {/* Horizontal Categories Scroll */}
            <div className="px-3.5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-slate-900 uppercase tracking-wide">
                  {t.allCategories}
                </span>
                {filters.category !== 'all' && (
                  <button
                    onClick={() => setFilters(prev => ({ ...prev, category: 'all' }))}
                    className="text-[11px] font-semibold text-orange-600 flex items-center gap-1"
                  >
                    <span>Tous voir</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                )}
              </div>

              <div className="flex gap-2.5 overflow-x-auto pb-1 no-scrollbar">
                {CATEGORIES.map(cat => {
                  const isSelected = filters.category === cat.id;
                  const IconComponent = categoryIconMap[cat.icon] || GridIcon;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => handleCategoryClick(cat.id)}
                      className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border transition shrink-0 w-[74px] cursor-pointer ${
                        isSelected
                          ? 'bg-orange-500 text-white border-orange-500 shadow-md scale-105'
                          : 'bg-white text-slate-700 border-slate-200/80 hover:bg-slate-50'
                      }`}
                    >
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center mb-1 transition ${
                          isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        <IconComponent className="w-4 h-4" />
                      </div>
                      <span className="text-[10px] font-bold text-center leading-tight line-clamp-1">
                        {cat.label[language].split(' ')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Active Filters summary if any applied */}
            {(filters.category !== 'all' ||
              filters.searchQuery ||
              filters.minPrice > 0 ||
              filters.maxPrice < 3000000 ||
              filters.inStockOnly ||
              filters.city !== 'all') && (
              <div className="px-3.5 flex items-center justify-between text-xs bg-orange-50/80 p-2.5 mx-3.5 rounded-xl border border-orange-200">
                <span className="text-orange-950 font-medium">
                  Filtres actifs ({filteredProducts.length} résultats)
                </span>
                <button
                  onClick={resetFilters}
                  className="text-orange-600 font-bold flex items-center gap-1 hover:underline"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Réinitialiser</span>
                </button>
              </div>
            )}

            {/* Product Grid */}
            <div className="px-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5 text-orange-500" />
                  <span>{t.featuredProducts}</span>
                </h3>
                <span className="text-[10px] text-slate-400 font-medium">
                  {filteredProducts.length} articles
                </span>
              </div>

              {filteredProducts.length === 0 ? (
                <div className="bg-white rounded-3xl p-8 border border-slate-200/80 text-center text-slate-400 space-y-3">
                  <Package className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="text-sm font-bold text-slate-700">Aucun produit ne correspond à votre recherche</p>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto">
                    Essayez de modifier vos filtres de prix, catégorie ou disponibilité.
                  </p>
                  <button
                    onClick={resetFilters}
                    className="px-4 py-2 bg-orange-500 text-white rounded-xl text-xs font-bold hover:bg-orange-600 transition"
                  >
                    Réinitialiser les filtres
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  {filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: CATEGORIES VIEW */}
        {activeTab === 'categories' && (
          <div className="p-4 space-y-4">
            <div>
              <h2 className="text-base font-black text-slate-900 tracking-tight">
                {t.allCategories}
              </h2>
              <p className="text-xs text-slate-500">
                Parcourez les rayons de vente en gros et au détail à Madagascar
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {CATEGORIES.map(cat => {
                const IconComponent = categoryIconMap[cat.icon] || GridIcon;
                const count = filteredProducts.filter(p => p.category === cat.id).length;
                return (
                  <button
                    key={cat.id}
                    onClick={() => handleCategoryClick(cat.id)}
                    className="bg-white p-4 rounded-2xl border border-slate-200 text-left hover:border-orange-500 hover:shadow-md transition flex flex-col justify-between group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center mb-3 group-hover:bg-orange-500 group-hover:text-white transition">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 group-hover:text-orange-600 transition">
                        {cat.label[language]}
                      </h4>
                      <span className="text-[10px] text-slate-400 mt-0.5 block">
                        {count} produits
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: FAVORITES VIEW */}
        {activeTab === 'favorites' && (
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-black text-slate-900 tracking-tight">
                  {t.navFavorites}
                </h2>
                <p className="text-xs text-slate-500">
                  Vos articles coup de cœur enregistrés
                </p>
              </div>
              <span className="text-xs bg-rose-50 text-rose-700 font-bold px-2.5 py-1 rounded-full border border-rose-200">
                {favorites.length}
              </span>
            </div>

            {favorites.length === 0 ? (
              <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center text-slate-400 space-y-2">
                <Heart className="w-10 h-10 text-slate-300 mx-auto" />
                <p className="text-sm font-bold text-slate-700">{t.noFavorites}</p>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  Touchez l'icône de cœur sur n'importe quel produit pour l'enregistrer dans votre liste de souhaits.
                </p>
                <button
                  onClick={() => setActiveTab('home')}
                  className="mt-2 px-4 py-2 bg-orange-500 text-white rounded-xl text-xs font-bold"
                >
                  Découvrir les produits
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {favorites.map(p => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: ORDERS VIEW */}
        {activeTab === 'orders' && (
          <OrderHistoryModal
            onOpenChatWithSeller={(sellerId, sellerName) =>
              openChat(sellerId, sellerName)
            }
          />
        )}

        {/* TAB 5: SELLER DASHBOARD VIEW */}
        {activeTab === 'seller' && (
          <SellerDashboard
            onOpenChatWithBuyer={(buyerId, buyerName) =>
              openChat(buyerId, buyerName)
            }
          />
        )}

        {/* TAB 6: ADMIN PANEL VIEW */}
        {activeTab === 'admin' && <AdminPanelModal />}

        {/* TAB 7: PROFILE VIEW (when not in seller/admin tab mode) */}
        {activeTab === 'profile' && (
          <div className="p-4 space-y-4">
            {/* User Card */}
            <div className="bg-slate-900 text-white rounded-3xl p-4 shadow-xl border border-slate-800 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-orange-500 text-white font-black text-xl flex items-center justify-center shadow">
                  {currentUser.name.charAt(0)}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">{currentUser.name}</h3>
                  <p className="text-[11px] text-slate-400">{currentUser.email}</p>
                  <p className="text-[10px] text-orange-400 font-semibold mt-0.5">
                    {currentUser.city}
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">Rôle actif :</span>
                <span className="text-[11px] font-bold bg-orange-500/20 text-orange-400 px-2.5 py-0.5 rounded-full border border-orange-500/30 uppercase">
                  {currentUser.role}
                </span>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden divide-y divide-slate-100 text-xs">
              <button
                onClick={() => setIsAuthOpen(true)}
                className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 transition text-slate-800 font-semibold"
              >
                <span>Modifier mes coordonnées & profil</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => setIsApkGuideOpen(true)}
                className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 transition text-slate-800 font-semibold"
              >
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-orange-500" />
                  <span>Guide Export APK Android installable</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => setIsFirebaseOpen(true)}
                className="w-full p-3.5 flex items-center justify-between hover:bg-slate-50 transition text-slate-800 font-semibold"
              >
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-600" />
                  <span>Configuration Cloud Firebase</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Modals & Overlays */}
      <ProductDetailModal
        product={selectedProductForDetail}
        onClose={() => setSelectedProductForDetail(null)}
        onDirectCheckout={handleDirectCheckout}
      />

      <ProductFilterModal
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onProceedToCheckout={() => setIsCheckoutOpen(true)}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => {
          setIsCheckoutOpen(false);
          setDirectCheckoutItem(null);
        }}
        directCheckoutItem={directCheckoutItem}
        onOrderSuccess={() => {
          // keep open for receipt display
        }}
      />

      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />

      <ChatModal />

      <FirebaseConfigModal
        isOpen={isFirebaseOpen}
        onClose={() => setIsFirebaseOpen(false)}
      />

      <AndroidApkGuideModal
        isOpen={isApkGuideOpen}
        onClose={() => setIsApkGuideOpen(false)}
      />
    </AndroidFrame>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <CartProvider>
          <MarketProvider>
            <MarketplaceContent />
          </MarketProvider>
        </CartProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}

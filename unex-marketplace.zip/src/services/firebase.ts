import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getStorage, FirebaseStorage } from 'firebase/storage';
import { FirebaseSettings } from '../types';

const STORAGE_KEY = 'unex_firebase_config';

export const getSavedFirebaseConfig = (): FirebaseSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.projectId && parsed.apiKey) {
        return { ...parsed, isConnected: true };
      }
    }
  } catch {
    // fallback
  }

  // Check env vars if present
  const envConfig: FirebaseSettings = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
    appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
    isConnected: !!(import.meta.env.VITE_FIREBASE_PROJECT_ID && import.meta.env.VITE_FIREBASE_API_KEY)
  };

  return envConfig;
};

export const saveFirebaseConfig = (config: Partial<FirebaseSettings>) => {
  const current = getSavedFirebaseConfig();
  const updated = {
    ...current,
    ...config,
    isConnected: !!(config.projectId && config.apiKey)
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updated;
};

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;
let storage: FirebaseStorage | null = null;

export const initFirebase = () => {
  const config = getSavedFirebaseConfig();
  if (!config.apiKey || !config.projectId) {
    return { app: null, auth: null, db: null, storage: null, isConfigured: false };
  }

  try {
    if (!getApps().length) {
      app = initializeApp({
        apiKey: config.apiKey,
        authDomain: config.authDomain || `${config.projectId}.firebaseapp.com`,
        projectId: config.projectId,
        storageBucket: config.storageBucket || `${config.projectId}.appspot.com`,
        messagingSenderId: config.messagingSenderId,
        appId: config.appId
      });
    } else {
      app = getApp();
    }

    auth = getAuth(app);
    db = getFirestore(app);
    storage = getStorage(app);

    return { app, auth, db, storage, isConfigured: true };
  } catch (err) {
    console.warn('Firebase initialization notice (running in local storage demo mode):', err);
    return { app: null, auth: null, db: null, storage: null, isConfigured: false };
  }
};

export const { auth: firebaseAuth, db: firestoreDb, storage: firebaseStorage } = initFirebase();

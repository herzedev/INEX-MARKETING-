import { Product, UserProfile, Order } from '../types';

export const INITIAL_USERS: UserProfile[] = [
  {
    id: 'user_buyer_1',
    name: 'Faly Rakotomalala',
    email: 'faly.rakoto@unex.mg',
    phone: '034 88 123 45',
    whatsapp: '261348812345',
    role: 'buyer',
    city: 'Antananarivo (Renivohitra)',
    address: 'Lot II M 45 Andravoahangy, Antananarivo',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    createdAt: '2026-01-15T08:00:00Z'
  },
  {
    id: 'user_seller_1',
    name: 'Andry Randriamanana',
    email: 'andry.tech@unex.mg',
    phone: '034 11 987 65',
    whatsapp: '261341198765',
    role: 'seller',
    city: 'Antananarivo (Avaradrano)',
    address: 'Analakely Arcade Shop #12',
    shopName: 'Mada Tech Pro',
    shopDescription: 'Distributeur officiel smartphones, accessoires certifiés et informatique à Antananarivo.',
    shopLogo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80',
    isVerifiedSeller: true,
    createdAt: '2025-11-10T10:00:00Z'
  },
  {
    id: 'user_seller_2',
    name: 'Mialy Razafindrakoto',
    email: 'mialy.mode@unex.mg',
    phone: '032 55 432 10',
    whatsapp: '261325543210',
    role: 'seller',
    city: 'Toamasina (Tamatave)',
    address: 'Boulevard Joffre, Tamatave',
    shopName: 'Tana & Tamatave Chic',
    shopDescription: 'Mode tendance, prêt-à-porter de qualité, tissus malgaches et accessoires stylés.',
    shopLogo: 'https://images.unsplash.com/photo-1544816155-12df9643f363?w=200&auto=format&fit=crop&q=80',
    isVerifiedSeller: true,
    createdAt: '2025-12-01T14:30:00Z'
  },
  {
    id: 'user_seller_3',
    name: 'Jean-Luc Ravalison',
    email: 'jeanluc.agri@unex.mg',
    phone: '038 99 777 88',
    whatsapp: '261389977788',
    role: 'seller',
    city: 'Antsirabe',
    address: 'Route d’Andraikiba, Antsirabe',
    shopName: 'Terroir & Agri Mada',
    shopDescription: 'Producteur et grossiste certifié : vanille Bourbon, miel d’eucalyptus et semences.',
    shopLogo: 'https://images.unsplash.com/photo-1595974482597-4b8da8879bc5?w=200&auto=format&fit=crop&q=80',
    isVerifiedSeller: true,
    createdAt: '2026-02-05T09:15:00Z'
  },
  {
    id: 'user_admin_1',
    name: 'Superviseur Unex',
    email: 'admin@unex.mg',
    phone: '034 00 000 01',
    role: 'admin',
    city: 'Antananarivo (Renivohitra)',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    createdAt: '2025-01-01T00:00:00Z'
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod_1',
    title: 'Samsung Galaxy A55 5G (128 Go, 8 Go RAM) Double SIM',
    description: 'Smartphone haut de gamme accessible avec écran Super AMOLED 120Hz, triple capteur photo 50MP et batterie 5000 mAh. Produit neuf dans son emballage d’origine avec garantie 12 mois. Compatible 4G/5G Telma, Orange et Airtel.',
    price: 1850000,
    wholesalePrice: 1720000,
    minWholesaleQty: 3,
    category: 'telephones',
    images: [
      'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=800&auto=format&fit=crop&q=80'
    ],
    stock: 14,
    deliveryFee: 5000,
    sellerId: 'user_seller_1',
    sellerName: 'Mada Tech Pro',
    sellerPhone: '034 11 987 65',
    sellerWhatsapp: '261341198765',
    sellerCity: 'Antananarivo',
    rating: 4.8,
    reviewsCount: 37,
    status: 'active',
    featured: true,
    createdAt: '2026-03-01T10:00:00Z'
  },
  {
    id: 'prod_2',
    title: 'Écouteurs Sans Fil Bluetooth ANC Pro V5.3 Autonomie 36h',
    description: 'Écouteurs intra-auriculaires avec réduction active de bruit, boîte de recharge LED et basse profonde. Idéal pour les appels nets et la musique dans les transports urbains.',
    price: 75000,
    wholesalePrice: 58000,
    minWholesaleQty: 5,
    category: 'accessoires',
    images: [
      'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80'
    ],
    stock: 48,
    deliveryFee: 4000,
    sellerId: 'user_seller_1',
    sellerName: 'Mada Tech Pro',
    sellerPhone: '034 11 987 65',
    sellerWhatsapp: '261341198765',
    sellerCity: 'Antananarivo',
    rating: 4.6,
    reviewsCount: 82,
    status: 'active',
    featured: true,
    createdAt: '2026-03-05T14:20:00Z'
  },
  {
    id: 'prod_3',
    title: 'Veste Coupe-Vent Imperméable Unisexe Tendance Urban',
    description: 'Veste légère étanche de haute qualité avec capuche réglable et poches zippées discrètes. Résiste parfaitement aux pluies d’été et aux brises côtières. Tailles disponibles M, L, XL, XXL.',
    price: 65000,
    wholesalePrice: 50000,
    minWholesaleQty: 6,
    category: 'vetements',
    images: [
      'https://images.unsplash.com/photo-1544441893-675973e31985?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&auto=format&fit=crop&q=80'
    ],
    stock: 35,
    deliveryFee: 4000,
    sellerId: 'user_seller_2',
    sellerName: 'Tana & Tamatave Chic',
    sellerPhone: '032 55 432 10',
    sellerWhatsapp: '261325543210',
    sellerCity: 'Toamasina (Tamatave)',
    rating: 4.9,
    reviewsCount: 54,
    status: 'active',
    featured: true,
    createdAt: '2026-03-10T11:00:00Z'
  },
  {
    id: 'prod_4',
    title: 'PC Portable Dell Latitude Core i5 16Go RAM SSD 512Go',
    description: 'Ordinateur portable reconditionné de niveau A+ certifié, écran 14 pouces Full HD antireflet, clavier rétroéclairé. Parfait pour la bureautique, télétravail, études et gestion commerciale.',
    price: 1450000,
    wholesalePrice: 1350000,
    minWholesaleQty: 2,
    category: 'informatique',
    images: [
      'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&auto=format&fit=crop&q=80'
    ],
    stock: 8,
    deliveryFee: 6000,
    sellerId: 'user_seller_1',
    sellerName: 'Mada Tech Pro',
    sellerPhone: '034 11 987 65',
    sellerWhatsapp: '261341198765',
    sellerCity: 'Antananarivo',
    rating: 4.7,
    reviewsCount: 29,
    status: 'active',
    featured: true,
    createdAt: '2026-03-12T09:30:00Z'
  },
  {
    id: 'prod_5',
    title: 'Gousses de Vanille Noire Gourmet Bourbon de Madagascar (Botte 250g)',
    description: 'Véritable vanille naturelle de la région SAVA (Sambava - Antalaha), taux d’humidité idéal (30-35%), parfum riche et vanilline élevée. Conditionnement sous vide hermétique pour grossistes et amateurs de pâtisserie.',
    price: 130000,
    wholesalePrice: 110000,
    minWholesaleQty: 4,
    category: 'agriculture',
    images: [
      'https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=800&auto=format&fit=crop&q=80'
    ],
    stock: 60,
    deliveryFee: 5000,
    sellerId: 'user_seller_3',
    sellerName: 'Terroir & Agri Mada',
    sellerPhone: '038 99 777 88',
    sellerWhatsapp: '261389977788',
    sellerCity: 'Antsirabe',
    rating: 5.0,
    reviewsCount: 91,
    status: 'active',
    featured: true,
    createdAt: '2026-03-14T08:45:00Z'
  },
  {
    id: 'prod_6',
    title: 'Miel Sauvage d’Eucalyptus Naturel d’Antsirabe (Pot 1 Kg)',
    description: 'Miel 100% pur non pasteurisé récolté dans les forêts des hautes terres d’Antsirabe. Riche en oligo-éléments, excellent antiseptique naturel pour la gorge et stimulant d’immunité.',
    price: 32000,
    wholesalePrice: 26000,
    minWholesaleQty: 6,
    category: 'agriculture',
    images: [
      'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=800&auto=format&fit=crop&q=80'
    ],
    stock: 80,
    deliveryFee: 4000,
    sellerId: 'user_seller_3',
    sellerName: 'Terroir & Agri Mada',
    sellerPhone: '038 99 777 88',
    sellerWhatsapp: '261389977788',
    sellerCity: 'Antsirabe',
    rating: 4.9,
    reviewsCount: 68,
    status: 'active',
    featured: false,
    createdAt: '2026-03-16T15:10:00Z'
  },
  {
    id: 'prod_7',
    title: 'Panneau Solaire Monocristallin 150W + Régulateur de Charge 20A',
    description: 'Kit solaire haute efficacité pour alimentation électrique maison, boutique ou éclairage rural. Conçu pour le fort ensoleillement de Madagascar. Cadre en aluminium renforcé avec verre trempé.',
    price: 295000,
    wholesalePrice: 265000,
    minWholesaleQty: 2,
    category: 'maison',
    images: [
      'https://images.unsplash.com/photo-1508873696983-2df570464756?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1509391365360-2e959784a276?w=800&auto=format&fit=crop&q=80'
    ],
    stock: 12,
    deliveryFee: 8000,
    sellerId: 'user_seller_1',
    sellerName: 'Mada Tech Pro',
    sellerPhone: '034 11 987 65',
    sellerWhatsapp: '261341198765',
    sellerCity: 'Antananarivo',
    rating: 4.8,
    reviewsCount: 42,
    status: 'active',
    featured: true,
    createdAt: '2026-03-17T12:00:00Z'
  },
  {
    id: 'prod_8',
    title: 'Huile Essentielle de Ravintsara Pure Bio de Madagascar (30 ml)',
    description: 'Cinnamomum camphora à cinéole 100% bio distillée artisanalement. L’incontournable des soins naturels malgaches pour renforcer les défenses immunitaires et purifier l’air ambiant.',
    price: 24000,
    wholesalePrice: 18000,
    minWholesaleQty: 10,
    category: 'beaute',
    images: [
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1617897903246-719242758050?w=800&auto=format&fit=crop&q=80'
    ],
    stock: 120,
    deliveryFee: 3000,
    sellerId: 'user_seller_3',
    sellerName: 'Terroir & Agri Mada',
    sellerPhone: '038 99 777 88',
    sellerWhatsapp: '261389977788',
    sellerCity: 'Antsirabe',
    rating: 4.9,
    reviewsCount: 115,
    status: 'active',
    featured: false,
    createdAt: '2026-03-18T16:20:00Z'
  },
  {
    id: 'prod_9',
    title: 'Sac à Main Artisanal en Raphia Tressé à la Main',
    description: 'Magnifique sac fait-main par des coopératives d’artisanat féminin. Poignées en cuir véritable résistant, intérieur doublé avec fermeture éclair. Finitions soignées.',
    price: 48000,
    wholesalePrice: 38000,
    minWholesaleQty: 5,
    category: 'autres',
    images: [
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&auto=format&fit=crop&q=80'
    ],
    stock: 25,
    deliveryFee: 4000,
    sellerId: 'user_seller_2',
    sellerName: 'Tana & Tamatave Chic',
    sellerPhone: '032 55 432 10',
    sellerWhatsapp: '261325543210',
    sellerCity: 'Toamasina (Tamatave)',
    rating: 4.7,
    reviewsCount: 38,
    status: 'active',
    featured: false,
    createdAt: '2026-03-19T13:40:00Z'
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'CMD-UNEX-9281',
    buyerId: 'user_buyer_1',
    buyerName: 'Faly Rakotomalala',
    buyerPhone: '034 88 123 45',
    buyerCity: 'Antananarivo (Renivohitra)',
    deliveryAddress: 'Lot II M 45 Andravoahangy, près de la pharmacie',
    notes: 'Appelez-moi dès que le livreur arrive devant le portail',
    items: [
      {
        productId: 'prod_2',
        title: 'Écouteurs Sans Fil Bluetooth ANC Pro V5.3',
        price: 75000,
        quantity: 1,
        image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
        sellerId: 'user_seller_1'
      }
    ],
    totalAmount: 79000,
    deliveryFee: 4000,
    paymentMethod: 'mvola',
    status: 'shipped',
    sellerIds: ['user_seller_1'],
    createdAt: '2026-03-18T10:15:00Z',
    updatedAt: '2026-03-19T08:00:00Z'
  },
  {
    id: 'CMD-UNEX-8742',
    buyerId: 'user_buyer_1',
    buyerName: 'Faly Rakotomalala',
    buyerPhone: '034 88 123 45',
    buyerCity: 'Antananarivo (Renivohitra)',
    deliveryAddress: 'Lot II M 45 Andravoahangy, Antananarivo',
    items: [
      {
        productId: 'prod_6',
        title: 'Miel Sauvage d’Eucalyptus Naturel d’Antsirabe (Pot 1 Kg)',
        price: 32000,
        quantity: 2,
        image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
        sellerId: 'user_seller_3'
      }
    ],
    totalAmount: 68000,
    deliveryFee: 4000,
    paymentMethod: 'cod',
    status: 'delivered',
    sellerIds: ['user_seller_3'],
    createdAt: '2026-03-10T14:00:00Z',
    updatedAt: '2026-03-12T16:30:00Z'
  }
];

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';
import { translations } from './translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations['fr'];
  formatMGA: (amount: number) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('unex_language') as Language;
    return saved && ['fr', 'mg', 'en'].includes(saved) ? saved : 'fr';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('unex_language', lang);
  };

  const t = translations[language] || translations.fr;

  const formatMGA = (amount: number): string => {
    if (isNaN(amount)) return '0 Ar';
    const formatted = new Intl.NumberFormat('fr-MG').format(Math.round(amount));
    return `${formatted} Ar`;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, formatMGA }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

import React, { useState } from 'react';
import { Package, Clock, CheckCircle, Truck, XCircle, ChevronRight, MapPin, Phone, MessageCircle } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useMarket } from '../../context/MarketContext';
import { Order, OrderStatus } from '../../types';

interface OrderHistoryModalProps {
  onSelectOrder?: (order: Order) => void;
  onOpenChatWithSeller: (sellerId: string, sellerName: string) => void;
}

export const OrderHistoryModal: React.FC<OrderHistoryModalProps> = ({
  onOpenChatWithSeller
}) => {
  const { t, formatMGA } = useLanguage();
  const { userOrders, updateOrderStatus } = useMarket();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return {
          label: t.statusPending,
          bg: 'bg-amber-50 text-amber-700 border-amber-200',
          icon: Clock
        };
      case 'confirmed':
        return {
          label: t.statusConfirmed,
          bg: 'bg-blue-50 text-blue-700 border-blue-200',
          icon: CheckCircle
        };
      case 'shipped':
        return {
          label: t.statusShipped,
          bg: 'bg-purple-50 text-purple-700 border-purple-200',
          icon: Truck
        };
      case 'delivered':
        return {
          label: t.statusDelivered,
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          icon: CheckCircle
        };
      case 'cancelled':
        return {
          label: t.statusCancelled,
          bg: 'bg-rose-50 text-rose-700 border-rose-200',
          icon: XCircle
        };
    }
  };

  return (
    <div className="p-4 space-y-4">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-black text-slate-900 tracking-tight">
            {t.navOrders}
          </h2>
          <p className="text-xs text-slate-500">
            Suivi en temps réel de vos achats sur Unex
          </p>
        </div>
        <span className="text-xs bg-slate-100 text-slate-700 font-bold px-2.5 py-1 rounded-full">
          {userOrders.length} {userOrders.length > 1 ? 'commandes' : 'commande'}
        </span>
      </div>

      {userOrders.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 border border-slate-200/80 text-center text-slate-400 space-y-3">
          <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto">
            <Package className="w-8 h-8 text-slate-300" />
          </div>
          <p className="text-sm font-bold text-slate-700">{t.noOrders}</p>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            Toutes vos futures commandes passées auprès des vendeurs apparaîtront ici.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {userOrders.map(order => {
            const badge = getStatusBadge(order.status);
            const BadgeIcon = badge.icon;
            const isPending = order.status === 'pending';

            return (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-3.5 space-y-3 transition hover:shadow-md"
              >
                {/* Top: ID, Date & Status */}
                <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                  <div>
                    <span className="font-extrabold text-xs text-slate-900 block">
                      {order.id}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(order.createdAt).toLocaleDateString('fr-FR', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric'
                      })}
                    </span>
                  </div>

                  <span
                    className={`text-[11px] font-bold px-2.5 py-1 rounded-full border flex items-center gap-1 ${badge.bg}`}
                  >
                    <BadgeIcon className="w-3 h-3" />
                    <span>{badge.label}</span>
                  </span>
                </div>

                {/* Items preview */}
                <div className="space-y-2">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2.5">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-11 h-11 rounded-lg object-cover border border-slate-200 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-slate-800 truncate">
                          {item.title}
                        </p>
                        <p className="text-[10px] text-slate-500">
                          Qté : {item.quantity} × {formatMGA(item.price)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Delivery Info & Total */}
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/60 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-slate-600 truncate max-w-[200px]">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{order.buyerCity}</span>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block leading-tight">Total</span>
                    <span className="font-extrabold text-xs text-slate-900">
                      {formatMGA(order.totalAmount)}
                    </span>
                  </div>
                </div>

                {/* Order Actions */}
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-1 text-[10px] text-slate-400 uppercase font-semibold">
                    <span>Paiement : {order.paymentMethod.toUpperCase()}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {isPending && (
                      <button
                        onClick={() => updateOrderStatus(order.id, 'cancelled')}
                        className="text-xs text-rose-600 hover:text-rose-700 font-semibold px-2 py-1 rounded border border-rose-200 hover:bg-rose-50"
                      >
                        Annuler
                      </button>
                    )}

                    <button
                      onClick={() =>
                        onOpenChatWithSeller(
                          order.sellerIds[0] || '',
                          'Vendeur Unex'
                        )
                      }
                      className="text-xs text-slate-700 bg-slate-100 hover:bg-slate-200 font-semibold px-2.5 py-1.5 rounded-xl flex items-center gap-1 transition"
                    >
                      <MessageCircle className="w-3 h-3 text-orange-500" />
                      <span>Contacter</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import {
  Shield,
  Users,
  Package,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Ban,
  DollarSign,
  TrendingUp,
  Search,
  Eye
} from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useMarket } from '../../context/MarketContext';
import { Product, UserProfile } from '../../types';

export const AdminPanelModal: React.FC = () => {
  const { t, formatMGA } = useLanguage();
  const { allUsers, suspendUser, currentUser } = useAuth();
  const { products, orders, moderateProduct, deleteProduct } = useMarket();

  const [adminTab, setAdminTab] = useState<'kpi' | 'products' | 'users' | 'orders'>('kpi');
  const [searchTerm, setSearchTerm] = useState('');

  // Protect Admin actions
  if (currentUser.role !== 'admin') {
    return (
      <div className="p-6 text-center text-slate-500">
        <Shield className="w-12 h-12 text-rose-500 mx-auto mb-2" />
        <h3 className="text-sm font-bold text-slate-900">Accès Administrateur Restreint</h3>
        <p className="text-xs text-slate-500 mt-1">
          Vous devez être connecté avec le rôle Administrateur pour accéder à cette interface.
        </p>
      </div>
    );
  }

  // Stats calculation
  const totalGMV = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const pendingModeration = products.filter(p => p.status === 'pending');
  const suspendedUsersCount = allUsers.filter(u => u.isSuspended).length;

  return (
    <div className="p-4 space-y-4">
      {/* Admin Title */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold shadow-md">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-black text-slate-900 tracking-tight">
              Console d'Administration Unex
            </h2>
            <p className="text-[10px] text-slate-400">
              Modération, gestion des vendeurs et gouvernance
            </p>
          </div>
        </div>

        <span className="text-[10px] bg-rose-100 text-rose-800 font-bold px-2 py-0.5 rounded-full">
          Super Admin
        </span>
      </div>

      {/* Tabs */}
      <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200 text-xs">
        {[
          { id: 'kpi', label: 'Vue Globale' },
          { id: 'products', label: `Produits (${products.length})` },
          { id: 'users', label: `Membres (${allUsers.length})` },
          { id: 'orders', label: `Commandes (${orders.length})` }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setAdminTab(tab.id as any)}
            className={`flex-1 py-1.5 rounded-xl font-bold transition text-center ${
              adminTab === tab.id
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Global KPI */}
      {adminTab === 'kpi' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Volume d'affaires (GMV)
              </span>
              <span className="text-base font-black text-slate-900 block">
                {formatMGA(totalGMV)}
              </span>
              <span className="text-[10px] text-emerald-600 font-medium">
                +18% ce mois-ci
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Total Commandes
              </span>
              <span className="text-base font-black text-slate-900 block">
                {orders.length}
              </span>
              <span className="text-[10px] text-blue-600 font-medium">
                Madagascar Global
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Vendeurs & Boutiques
              </span>
              <span className="text-base font-black text-slate-900 block">
                {allUsers.filter(u => u.role === 'seller').length}
              </span>
              <span className="text-[10px] text-orange-600 font-medium">
                Certifiés
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Articles en ligne
              </span>
              <span className="text-base font-black text-slate-900 block">
                {products.length}
              </span>
              <span className="text-[10px] text-slate-500 font-medium">
                Toutes catégories
              </span>
            </div>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3.5 space-y-1 text-xs text-amber-900">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Contrôle de conformité et sécurité</span>
            </div>
            <p className="text-[11px] text-amber-800">
              Chaque produit publié fait l'objet d'un contrôle automatique de prix en Ariary (MGA) et de stock non négatif. En cas de suspicion d'escroquerie, vous pouvez suspendre instantanément le compte du vendeur.
            </p>
          </div>
        </div>
      )}

      {/* Tab 2: Products Moderation */}
      {adminTab === 'products' && (
        <div className="space-y-3">
          {products.map(p => (
            <div
              key={p.id}
              className="bg-white rounded-2xl border border-slate-200 p-3 flex gap-3 items-center"
            >
              <img
                src={p.images[0]}
                alt=""
                className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
              />

              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-slate-900 line-clamp-1">
                  {p.title}
                </h4>
                <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5">
                  <span>{formatMGA(p.price)}</span>
                  <span>•</span>
                  <span>Stock: {p.stock}</span>
                  <span>•</span>
                  <span>Vendeur: {p.sellerName}</span>
                </div>
              </div>

              {/* Moderation Actions */}
              <div className="flex items-center gap-1 shrink-0">
                {p.status === 'pending' ? (
                  <>
                    <button
                      onClick={() => moderateProduct(p.id, 'active')}
                      className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700"
                      title="Approuver le produit"
                    >
                      <CheckCircle className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => moderateProduct(p.id, 'rejected')}
                      className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700"
                      title="Rejeter le produit"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => deleteProduct(p.id)}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-rose-100 text-slate-500 hover:text-rose-600 transition"
                    title="Supprimer définitivement"
                  >
                    <XCircle className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Users Management */}
      {adminTab === 'users' && (
        <div className="space-y-3">
          {allUsers.map(user => {
            const isMe = user.id === currentUser.id;
            return (
              <div
                key={user.id}
                className="bg-white rounded-2xl border border-slate-200 p-3 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-slate-800 text-white font-bold text-xs flex items-center justify-center">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-900">
                        {user.name}
                      </span>
                      {user.role === 'seller' && (
                        <span className="text-[9px] bg-orange-100 text-orange-800 font-bold px-1.5 rounded">
                          Vendeur
                        </span>
                      )}
                      {user.role === 'admin' && (
                        <span className="text-[9px] bg-rose-100 text-rose-800 font-bold px-1.5 rounded">
                          Admin
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-500">
                      {user.phone} • {user.city}
                    </p>
                  </div>
                </div>

                {/* Suspension action */}
                {!isMe && (
                  <button
                    onClick={() => suspendUser(user.id, !user.isSuspended)}
                    className={`text-xs font-semibold px-2.5 py-1 rounded-xl transition ${
                      user.isSuspended
                        ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                        : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                    }`}
                  >
                    {user.isSuspended ? 'Réactiver' : 'Suspendre'}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 4: All Orders */}
      {adminTab === 'orders' && (
        <div className="space-y-3">
          {orders.map(order => (
            <div
              key={order.id}
              className="bg-white rounded-2xl border border-slate-200 p-3 space-y-1.5 text-xs"
            >
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-slate-900">{order.id}</span>
                <span className="text-[10px] font-bold uppercase text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                  {order.status}
                </span>
              </div>
              <p className="text-slate-600">
                Acheteur : <strong className="text-slate-800">{order.buyerName}</strong> ({order.buyerPhone})
              </p>
              <p className="text-slate-500">
                Destination : {order.buyerCity} - {order.deliveryAddress}
              </p>
              <div className="flex justify-between items-center pt-1 border-t border-slate-100">
                <span className="text-slate-500">Paiement : {order.paymentMethod.toUpperCase()}</span>
                <span className="font-black text-orange-600">{formatMGA(order.totalAmount)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

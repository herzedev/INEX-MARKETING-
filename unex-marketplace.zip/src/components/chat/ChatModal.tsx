import React, { useState, useEffect, useRef } from 'react';
import { X, Send, Phone, MessageSquare, Check, CheckCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useMarket } from '../../context/MarketContext';
import { useLanguage } from '../../i18n/LanguageContext';

export const ChatModal: React.FC = () => {
  const { currentUser } = useAuth();
  const { activeChatTarget, closeChat, messages, sendMessage } = useMarket();
  const { formatMGA } = useLanguage();
  const [inputText, setInputText] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeChatTarget]);

  if (!activeChatTarget) return null;

  const convId = [currentUser.id, activeChatTarget.id].sort().join('__');
  const threadMessages = messages.filter(m => m.conversationId === convId);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    sendMessage(
      activeChatTarget.id,
      activeChatTarget.name,
      inputText.trim(),
      activeChatTarget.product
    );
    setInputText('');
  };

  const handleWhatsApp = () => {
    const phone = '261340000000';
    const msg = encodeURIComponent(
      `Bonjour ${activeChatTarget.name}, je vous contacte depuis Unex Marketplace.`
    );
    window.open(`https://wa.me/${phone}?text=${msg}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-md h-[80vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-4 py-3 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-orange-500 text-white font-bold text-xs flex items-center justify-center">
              {activeChatTarget.name.charAt(0)}
            </div>
            <div>
              <h3 className="text-xs font-bold text-white flex items-center gap-1">
                {activeChatTarget.name}
              </h3>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                En ligne sur Unex
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleWhatsApp}
              className="p-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs"
              title="Passer sur WhatsApp"
            >
              <Phone className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={closeChat}
              className="p-1 rounded-full hover:bg-slate-800 text-slate-400"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Product Reference Banner (if product context is attached) */}
        {activeChatTarget.product && (
          <div className="bg-orange-50/80 border-b border-orange-200/80 p-2.5 flex items-center gap-2.5">
            <img
              src={activeChatTarget.product.images[0]}
              alt=""
              className="w-10 h-10 rounded-lg object-cover border border-orange-200 shrink-0"
            />
            <div className="flex-1 min-w-0 text-xs">
              <span className="text-[10px] text-orange-800 font-semibold uppercase block">
                Objet de la conversation
              </span>
              <p className="font-bold text-slate-900 truncate">
                {activeChatTarget.product.title}
              </p>
              <p className="text-[11px] font-extrabold text-orange-600">
                {formatMGA(activeChatTarget.product.price)}
              </p>
            </div>
          </div>
        )}

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50 no-scrollbar">
          {threadMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 p-6">
              <MessageSquare className="w-8 h-8 text-slate-300 mb-2" />
              <p className="text-xs font-semibold text-slate-600">
                Commencez la discussion avec {activeChatTarget.name}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Posez vos questions sur la disponibilité, les remises de gros ou les modalités de livraison à Madagascar.
              </p>
            </div>
          ) : (
            threadMessages.map(msg => {
              const isMe = msg.senderId === currentUser.id;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[78%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed ${
                      isMe
                        ? 'bg-slate-900 text-white rounded-br-none shadow-xs'
                        : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-none shadow-xs'
                    }`}
                  >
                    <p>{msg.text}</p>
                  </div>
                  <span className="text-[9px] text-slate-400 mt-1 px-1">
                    {new Date(msg.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              );
            })
          )}
          <div ref={endRef} />
        </div>

        {/* Input Form */}
        <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-100 flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            placeholder="Écrivez votre message..."
            className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="w-9 h-9 rounded-xl bg-orange-500 hover:bg-orange-600 text-white flex items-center justify-center transition disabled:opacity-40"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};

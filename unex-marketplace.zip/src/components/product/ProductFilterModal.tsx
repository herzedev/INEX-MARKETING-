import React from 'react';
import { X, RotateCcw, Check } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useMarket } from '../../context/MarketContext';
import { CATEGORIES, MADAGASCAR_CITIES } from '../../i18n/translations';
import { ProductCategory } from '../../types';

interface ProductFilterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProductFilterModal: React.FC<ProductFilterModalProps> = ({
  isOpen,
  onClose
}) => {
  const { t, formatMGA, language } = useLanguage();
  const { filters, setFilters, resetFilters } = useMarket();

  if (!isOpen) return null;

  const handlePricePreset = (max: number) => {
    setFilters(prev => ({ ...prev, minPrice: 0, maxPrice: max }));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-slate-900">{t.filters}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={resetFilters}
              className="text-xs text-orange-600 hover:text-orange-700 flex items-center gap-1 font-medium px-2 py-1 rounded"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{t.clearFilters}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-full hover:bg-slate-100 text-slate-500"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-5 no-scrollbar">
          {/* Categories */}
          <div>
            <label className="text-xs font-bold text-slate-900 block mb-2 uppercase tracking-wide">
              {t.navCategories}
            </label>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setFilters(prev => ({ ...prev, category: 'all' }))}
                className={`text-xs px-3 py-1.5 rounded-xl border transition ${
                  filters.category === 'all'
                    ? 'bg-slate-900 text-white border-slate-900 font-semibold shadow-xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {t.allCategories}
              </button>
              {CATEGORIES.map(cat => {
                const isSelected = filters.category === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() =>
                      setFilters(prev => ({
                        ...prev,
                        category: cat.id as ProductCategory
                      }))
                    }
                    className={`text-xs px-3 py-1.5 rounded-xl border transition ${
                      isSelected
                        ? 'bg-orange-500 text-white border-orange-500 font-semibold shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {cat.label[language]}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                {t.priceRange}
              </label>
              <span className="text-xs font-bold text-orange-600">
                Max : {filters.maxPrice >= 3000000 ? 'Illimité' : formatMGA(filters.maxPrice)}
              </span>
            </div>

            <input
              type="range"
              min="0"
              max="3000000"
              step="25000"
              value={filters.maxPrice}
              onChange={e =>
                setFilters(prev => ({ ...prev, maxPrice: Number(e.target.value) }))
              }
              className="w-full accent-orange-500 cursor-pointer h-2 bg-slate-200 rounded-lg"
            />

            {/* Quick Price Buttons */}
            <div className="grid grid-cols-4 gap-1.5 mt-2.5">
              {[50000, 200000, 1000000, 3000000].map(price => (
                <button
                  key={price}
                  onClick={() => handlePricePreset(price)}
                  className={`text-[10px] py-1 px-1 rounded-lg border text-center transition font-medium ${
                    filters.maxPrice === price
                      ? 'bg-orange-500 text-white border-orange-500 font-bold'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {price === 3000000 ? 'Tout' : `< ${Math.round(price / 1000)}k`}
                </button>
              ))}
            </div>
          </div>

          {/* Availability Toggle */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-900 block">
                Articles en stock seulement
              </span>
              <span className="text-[11px] text-slate-500">
                Masquer les produits temporairement épuisés
              </span>
            </div>
            <input
              type="checkbox"
              checked={filters.inStockOnly}
              onChange={e =>
                setFilters(prev => ({ ...prev, inStockOnly: e.target.checked }))
              }
              className="w-5 h-5 accent-orange-500 cursor-pointer rounded"
            />
          </div>

          {/* City / Province in Madagascar */}
          <div>
            <label className="text-xs font-bold text-slate-900 block mb-2 uppercase tracking-wide">
              Localisation du vendeur
            </label>
            <select
              value={filters.city}
              onChange={e =>
                setFilters(prev => ({ ...prev, city: e.target.value }))
              }
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 font-medium focus:outline-none focus:border-orange-500"
            >
              <option value="all">Tout Madagascar (Toutes les provinces)</option>
              {MADAGASCAR_CITIES.map(city => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
          </div>

          {/* Sort By */}
          <div>
            <label className="text-xs font-bold text-slate-900 block mb-2 uppercase tracking-wide">
              Trier les résultats
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'featured', label: 'Recommandés' },
                { id: 'newest', label: 'Nouveautés' },
                { id: 'price_asc', label: 'Prix croissant' },
                { id: 'price_desc', label: 'Prix décroissant' },
                { id: 'rating', label: 'Mieux notés' }
              ].map(opt => (
                <button
                  key={opt.id}
                  onClick={() =>
                    setFilters(prev => ({ ...prev, sortBy: opt.id as any }))
                  }
                  className={`text-xs p-2 rounded-xl border text-left flex items-center justify-between transition ${
                    filters.sortBy === opt.id
                      ? 'bg-orange-50 border-orange-500 text-orange-900 font-bold'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span>{opt.label}</span>
                  {filters.sortBy === opt.id && (
                    <Check className="w-3.5 h-3.5 text-orange-600" />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-100 bg-white">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow-md transition"
          >
            {t.applyFilters}
          </button>
        </div>
      </div>
    </div>
  );
};

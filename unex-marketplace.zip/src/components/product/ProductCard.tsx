import React from 'react';
import { Heart, Plus, Star, CheckCircle, MapPin, PackageCheck } from 'lucide-react';
import { Product } from '../../types';
import { useLanguage } from '../../i18n/LanguageContext';
import { useCart } from '../../context/CartContext';
import { useMarket } from '../../context/MarketContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { formatMGA, t } = useLanguage();
  const { addToCart, toggleFavorite, isFavorite } = useCart();
  const { setSelectedProductForDetail } = useMarket();

  const isFav = isFavorite(product.id);
  const isOutOfStock = product.stock <= 0;

  const handleCardClick = () => {
    setSelectedProductForDetail(product);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isOutOfStock) {
      addToCart(product, 1);
    }
  };

  const handleToggleFav = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(product);
  };

  return (
    <div
      onClick={handleCardClick}
      className="bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col overflow-hidden cursor-pointer group"
    >
      {/* Product Image Box */}
      <div className="relative aspect-square w-full bg-slate-100 overflow-hidden">
        <img
          src={product.images[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80'}
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />

        {/* Favorite Button */}
        <button
          onClick={handleToggleFav}
          aria-label="Ajouter aux favoris"
          className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/90 backdrop-blur-md shadow flex items-center justify-center transition active:scale-90 hover:bg-white"
        >
          <Heart
            className={`w-4 h-4 transition ${
              isFav ? 'text-rose-500 fill-rose-500' : 'text-slate-600'
            }`}
          />
        </button>

        {/* Wholesale & Stock Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1 items-start">
          {product.wholesalePrice && (
            <span className="bg-orange-500/95 text-white font-extrabold text-[9px] px-2 py-0.5 rounded-md shadow uppercase tracking-wider backdrop-blur-xs">
              Gros dès {product.minWholesaleQty || 3} pcs
            </span>
          )}
          {isOutOfStock ? (
            <span className="bg-rose-600/95 text-white font-bold text-[9px] px-1.5 py-0.5 rounded shadow">
              {t.outOfStock}
            </span>
          ) : product.stock <= 5 ? (
            <span className="bg-amber-600/95 text-white font-bold text-[9px] px-1.5 py-0.5 rounded shadow">
              Plus que {product.stock}
            </span>
          ) : null}
        </div>
      </div>

      {/* Product Info */}
      <div className="p-3 flex-1 flex flex-col justify-between">
        <div>
          {/* Seller & Location */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
            <span className="truncate max-w-[120px] font-medium flex items-center gap-0.5">
              {product.sellerName}
              <CheckCircle className="w-2.5 h-2.5 text-blue-500 shrink-0 inline ml-0.5" />
            </span>
            <span className="text-[10px] text-slate-400 flex items-center shrink-0">
              <MapPin className="w-2.5 h-2.5 mr-0.5 text-slate-400" />
              {product.sellerCity.split(' ')[0]}
            </span>
          </div>

          {/* Title */}
          <h3 className="text-xs font-semibold text-slate-800 line-clamp-2 leading-snug group-hover:text-orange-600 transition">
            {product.title}
          </h3>
        </div>

        {/* Rating and Price Row */}
        <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-end justify-between">
          <div>
            <div className="flex items-center gap-1 text-[10px] text-amber-500 mb-0.5 font-bold">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>{product.rating.toFixed(1)}</span>
              <span className="text-slate-400 font-normal">({product.reviewsCount})</span>
            </div>

            {/* Price */}
            <div className="flex flex-col">
              <span className="text-sm font-extrabold text-slate-900 tracking-tight leading-none">
                {formatMGA(product.price)}
              </span>
              {product.wholesalePrice && (
                <span className="text-[10px] font-semibold text-orange-600 leading-tight">
                  {formatMGA(product.wholesalePrice)} / gros
                </span>
              )}
            </div>
          </div>

          {/* Quick Add To Cart Button */}
          <button
            onClick={handleAddToCart}
            disabled={isOutOfStock}
            className={`w-8 h-8 rounded-xl flex items-center justify-center transition active:scale-95 cursor-pointer shadow-sm ${
              isOutOfStock
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-orange-500 hover:bg-orange-600 text-white shadow-orange-500/20'
            }`}
            title={isOutOfStock ? t.outOfStock : t.addToCart}
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </div>
  );
};

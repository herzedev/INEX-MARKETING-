import React, { useState } from 'react';
import {
  X,
  Heart,
  Star,
  CheckCircle,
  Truck,
  ShieldCheck,
  MessageCircle,
  Phone,
  Share2,
  MapPin,
  Package,
  Layers
} from 'lucide-react';
import { Product } from '../../types';
import { useLanguage } from '../../i18n/LanguageContext';
import { useCart } from '../../context/CartContext';
import { useMarket } from '../../context/MarketContext';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onDirectCheckout: (product: Product, quantity: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onDirectCheckout
}) => {
  const { formatMGA, t } = useLanguage();
  const { addToCart, toggleFavorite, isFavorite } = useCart();
  const { openChat } = useMarket();

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [copied, setCopied] = useState(false);

  if (!product) return null;

  const isFav = isFavorite(product.id);
  const isOutOfStock = product.stock <= 0;
  const isWholesaleEligible =
    product.wholesalePrice &&
    product.minWholesaleQty &&
    quantity >= product.minWholesaleQty;

  const currentUnitPrice = isWholesaleEligible
    ? product.wholesalePrice!
    : product.price;

  const totalPrice = currentUnitPrice * quantity;

  const handleAddToCart = () => {
    addToCart(product, quantity);
    onClose();
  };

  const handleBuyNow = () => {
    onDirectCheckout(product, quantity);
    onClose();
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(
        `Découvrez ${product.title} à ${formatMGA(product.price)} sur Unex Marketplace !`
      );
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // WhatsApp integration: opens real WhatsApp with pre-filled message
  const handleOpenWhatsApp = () => {
    const phone = product.sellerWhatsapp || '261340000000';
    const message = encodeURIComponent(
      `Bonjour ${product.sellerName}, je vous contacte depuis Unex Marketplace au sujet de votre produit "${product.title}" (${formatMGA(product.price)}). Est-il toujours disponible ?`
    );
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  const handleOpenChat = () => {
    openChat(product.sellerId, product.sellerName, product);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-lg max-h-[92vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Modal Header */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-white z-10">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Détails de l'article
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 transition"
              title="Partager"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => toggleFavorite(product)}
              className="p-1.5 rounded-full hover:bg-slate-100 transition"
              title="Favoris"
            >
              <Heart
                className={`w-4 h-4 ${
                  isFav ? 'text-rose-500 fill-rose-500' : 'text-slate-500'
                }`}
              />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 transition"
              aria-label="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {copied && (
          <div className="bg-emerald-500 text-white text-xs text-center py-1 font-medium animate-pulse">
            Lien copié dans le presse-papier !
          </div>
        )}

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
          {/* Main Image Gallery */}
          <div className="space-y-2">
            <div className="relative aspect-4/3 w-full bg-slate-100 rounded-2xl overflow-hidden border border-slate-200/80">
              <img
                src={product.images[selectedImageIndex] || product.images[0]}
                alt={product.title}
                className="w-full h-full object-cover"
              />
              {product.wholesalePrice && (
                <div className="absolute top-3 left-3 bg-orange-600 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg shadow-md flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5" />
                  <span>Tarif de gros disponible</span>
                </div>
              )}
            </div>

            {/* Thumbnail selector if multiple images */}
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto py-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`relative w-14 h-14 rounded-xl overflow-hidden border-2 shrink-0 transition ${
                      selectedImageIndex === idx
                        ? 'border-orange-500 scale-105'
                        : 'border-slate-200 opacity-70'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Pricing Box */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/70">
            <div className="flex items-baseline justify-between">
              <div>
                <span className="text-2xl font-black text-slate-900 tracking-tight">
                  {formatMGA(currentUnitPrice)}
                </span>
                {isWholesaleEligible && (
                  <span className="ml-2 text-xs text-emerald-600 font-bold bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                    Remise gros appliquée
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1 text-amber-500 font-bold text-xs">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>{product.rating.toFixed(1)}</span>
                <span className="text-slate-400 font-normal">({product.reviewsCount} avis)</span>
              </div>
            </div>

            {/* Wholesale Tier Banner (Alibaba style) */}
            {product.wholesalePrice && (
              <div className="mt-2.5 pt-2.5 border-t border-slate-200 text-xs flex items-center justify-between text-slate-700 bg-orange-50/60 p-2 rounded-xl">
                <div>
                  <span className="font-bold text-orange-900">Palier de gros :</span>{' '}
                  <span className="text-slate-600">Dès {product.minWholesaleQty || 3} pièces</span>
                </div>
                <span className="font-extrabold text-orange-600">
                  {formatMGA(product.wholesalePrice)} / pièce
                </span>
              </div>
            )}
          </div>

          {/* Product Title & Stock Status */}
          <div>
            <h1 className="text-base font-bold text-slate-900 leading-snug">
              {product.title}
            </h1>

            <div className="mt-2 flex items-center gap-3 text-xs">
              {isOutOfStock ? (
                <span className="text-rose-600 font-bold bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200">
                  {t.outOfStock}
                </span>
              ) : (
                <span className="text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  {t.inStock} ({product.stock} {t.unitsAvailable})
                </span>
              )}

              <span className="text-slate-500 flex items-center gap-1">
                <Truck className="w-3.5 h-3.5 text-slate-400" />
                Livraison: {product.deliveryFee > 0 ? formatMGA(product.deliveryFee) : t.freeDelivery}
              </span>
            </div>
          </div>

          {/* Quantity Selector */}
          {!isOutOfStock && (
            <div className="flex items-center justify-between bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
              <span className="text-xs font-semibold text-slate-700">Quantité :</span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="w-8 h-8 rounded-lg bg-white border border-slate-300 text-slate-700 font-bold flex items-center justify-center hover:bg-slate-100 active:scale-95 transition"
                >
                  -
                </button>
                <span className="font-extrabold text-sm text-slate-900 w-8 text-center">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(q => Math.min(product.stock, q + 1))}
                  className="w-8 h-8 rounded-lg bg-white border border-slate-300 text-slate-700 font-bold flex items-center justify-center hover:bg-slate-100 active:scale-95 transition"
                >
                  +
                </button>
              </div>
            </div>
          )}

          {/* Description */}
          <div className="space-y-1.5">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Description du produit
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line bg-white p-3 rounded-xl border border-slate-100">
              {product.description}
            </p>
          </div>

          {/* Seller Profile Card */}
          <div className="bg-slate-900 text-white p-3.5 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-orange-500 flex items-center justify-center text-white font-bold text-sm shadow">
                  {product.sellerName.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-bold text-xs text-white">
                      {product.sellerName}
                    </span>
                    <CheckCircle className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />
                  </div>
                  <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3 text-slate-400" />
                    {product.sellerCity}
                  </p>
                </div>
              </div>

              <span className="text-[10px] bg-slate-800 text-orange-400 font-semibold px-2 py-1 rounded-md border border-slate-700">
                Vendeur Pro
              </span>
            </div>

            {/* Direct Contact Actions (Internal Chat & WhatsApp) */}
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800">
              <button
                onClick={handleOpenChat}
                className="flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium py-2 rounded-xl border border-slate-700 transition"
              >
                <MessageCircle className="w-3.5 h-3.5 text-orange-400" />
                <span>Message Unex</span>
              </button>

              <button
                onClick={handleOpenWhatsApp}
                className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold py-2 rounded-xl transition shadow"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </button>
            </div>
          </div>

          {/* Buyer Protection Guarantee */}
          <div className="flex items-center gap-2 text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-200/60">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Paiement sécurisé ou à la livraison avec vérification de conformité Unex.</span>
          </div>
        </div>

        {/* Modal Bottom Sticky Actions */}
        <div className="p-3 bg-white border-t border-slate-100 flex items-center gap-2.5">
          <button
            onClick={handleAddToCart}
            disabled={isOutOfStock}
            className={`flex-1 py-3 px-4 rounded-xl text-xs font-bold border transition active:scale-98 flex items-center justify-center gap-1.5 ${
              isOutOfStock
                ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300 shadow-xs'
            }`}
          >
            <Package className="w-4 h-4 text-orange-500" />
            <span>{t.addToCart}</span>
          </button>

          <button
            onClick={handleBuyNow}
            disabled={isOutOfStock}
            className={`flex-1 py-3 px-4 rounded-xl text-xs font-extrabold transition active:scale-98 shadow-md flex items-center justify-center gap-1.5 ${
              isOutOfStock
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 text-white shadow-orange-500/25'
            }`}
          >
            <span>{t.buyNow} ({formatMGA(totalPrice)})</span>
          </button>
        </div>
      </div>
    </div>
  );
};

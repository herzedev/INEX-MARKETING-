import React, { useState } from 'react';
import { X, Smartphone, Terminal, CheckCircle2, Copy, Layers, ExternalLink, ShieldCheck } from 'lucide-react';

interface AndroidApkGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidApkGuideModal: React.FC<AndroidApkGuideModalProps> = ({
  isOpen,
  onClose
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const copyCode = (text: string, index: number) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    }
  };

  const codeSnippets = [
    `# 1. Lancer le projet en local
npm install
npm run dev`,
    `# 2. Ajouter le moteur Capacitor pour Android
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init Unex com.unex.marketplace --web-dir dist`,
    `# 3. Compiler l'application et générer le projet Android
npm run build
npx cap add android
npx cap sync android`,
    `# 4. Ouvrir dans Android Studio et produire l'APK
npx cap open android
# Dans Android Studio: Menu Build > Build Bundle(s) / APK(s) > Build APK(s)`
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[88vh] overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-orange-400" />
            <h2 className="text-sm font-bold">
              Générer l'APK Android & Déploiement
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-slate-800 text-slate-400"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar text-xs">
          {/* Summary badge */}
          <div className="bg-orange-50 border border-orange-200 rounded-2xl p-3 text-orange-950 space-y-1">
            <span className="font-bold block">
              Application Unex Marketplace prête pour Android
            </span>
            <p className="text-[11px] text-orange-800">
              L'architecture du projet est conçue pour fonctionner comme une Progressive Web App (PWA) et être empaquetée directement en fichier <strong>.APK</strong> natif via Capacitor.
            </p>
          </div>

          {/* Steps */}
          <div className="space-y-3">
            <h3 className="font-bold text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-orange-500" />
              <span>Commandes pour générer le fichier .APK</span>
            </h3>

            {codeSnippets.map((snippet, idx) => (
              <div key={idx} className="bg-slate-900 text-slate-100 rounded-2xl p-3 font-mono text-[11px] relative group">
                <pre className="whitespace-pre-wrap leading-relaxed">{snippet}</pre>
                <button
                  onClick={() => copyCode(snippet, idx)}
                  className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition flex items-center gap-1 text-[10px]"
                >
                  <Copy className="w-3 h-3" />
                  <span>{copiedIndex === idx ? 'Copié !' : 'Copier'}</span>
                </button>
              </div>
            ))}
          </div>

          {/* Installation on phone instructions */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Comment installer le fichier APK sur un téléphone Android :</span>
            </h4>
            <ol className="list-decimal list-inside space-y-1 text-slate-600 text-[11px] leading-relaxed">
              <li>Le fichier généré se trouvera dans <code>android/app/build/outputs/apk/debug/app-debug.apk</code>.</li>
              <li>Transférez-le sur votre smartphone (via câble USB, WhatsApp ou Google Drive).</li>
              <li>Sur votre Android, autorisez l'installation d'applications de sources inconnues si demandé.</li>
              <li>Touchez le fichier <code>app-debug.apk</code> pour lancer l'installation. L'icône Unex apparaîtra sur l'écran d'accueil !</li>
            </ol>
          </div>

          {/* Status Matrix */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden">
            <div className="bg-slate-100 px-3 py-2 font-bold text-slate-800 border-b border-slate-200">
              Matrice de fonctionnement des fonctionnalités :
            </div>
            <div className="p-3 space-y-2 text-[11px]">
              <div className="flex items-center gap-2 text-emerald-700">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span><strong>100% Fonctionnel :</strong> Navigation, catalogue, recherche, filtres en MGA, panier, remises gros, commandes, panel vendeur, panel admin, messagerie, WhatsApp.</span>
              </div>
              <div className="flex items-center gap-2 text-blue-700">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span><strong>Firebase :</strong> Fichiers <code>firestore.rules</code> et <code>firebase-blueprint.json</code> prêts. Connexion active dès que vous entrez vos identifiants Firebase.</span>
              </div>
              <div className="flex items-center gap-2 text-amber-700">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span><strong>Paiement Mobile Money :</strong> Choix MVola / Orange / Airtel Money enregistrés dans la commande. Prêt pour l'intégration des webhooks API opérateurs.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

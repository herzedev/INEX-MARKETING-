import React, { useState } from 'react';
import { X, Database, ShieldCheck, CheckCircle2, Copy, AlertCircle, Save } from 'lucide-react';
import { getSavedFirebaseConfig, saveFirebaseConfig } from '../../services/firebase';
import { FirebaseSettings } from '../../types';

interface FirebaseConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FirebaseConfigModal: React.FC<FirebaseConfigModalProps> = ({
  isOpen,
  onClose
}) => {
  const currentConfig = getSavedFirebaseConfig();
  const [apiKey, setApiKey] = useState(currentConfig.apiKey || '');
  const [projectId, setProjectId] = useState(currentConfig.projectId || '');
  const [authDomain, setAuthDomain] = useState(currentConfig.authDomain || '');
  const [storageBucket, setStorageBucket] = useState(currentConfig.storageBucket || '');
  const [appId, setAppId] = useState(currentConfig.appId || '');
  const [saved, setSaved] = useState(false);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveFirebaseConfig({
      apiKey,
      projectId,
      authDomain,
      storageBucket,
      appId
    });
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      window.location.reload();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-orange-500" />
            <h2 className="text-sm font-bold text-slate-900">
              Connexion Firebase (Firestore, Auth & Storage)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-slate-100 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
          {/* Status card */}
          <div className={`p-3 rounded-2xl border flex items-center justify-between ${
            currentConfig.isConnected
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-amber-50 border-amber-200 text-amber-800'
          }`}>
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${currentConfig.isConnected ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`} />
              <div>
                <span className="text-xs font-bold block">
                  {currentConfig.isConnected
                    ? 'Connecté au Cloud Firestore'
                    : 'Mode Démonstration Fonctionnelle (Stockage Local Réactif)'}
                </span>
                <span className="text-[11px] opacity-80">
                  {currentConfig.isConnected
                    ? `Projet ID : ${currentConfig.projectId}`
                    : 'Toutes les actions (produits, panier, commandes) fonctionnent immédiatement avec données en cache'}
                </span>
              </div>
            </div>
          </div>

          {/* Form to insert own keys */}
          <form onSubmit={handleSave} className="space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Paramètres du Projet Firebase
            </h3>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Firebase Project ID
              </label>
              <input
                type="text"
                value={projectId}
                onChange={e => setProjectId(e.target.value)}
                placeholder="Ex: unex-marketplace-mada"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                API Key
              </label>
              <input
                type="text"
                value={apiKey}
                onChange={e => setApiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Auth Domain (optionnel)
                </label>
                <input
                  type="text"
                  value={authDomain}
                  onChange={e => setAuthDomain(e.target.value)}
                  placeholder="unex.firebaseapp.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Storage Bucket (optionnel)
                </label>
                <input
                  type="text"
                  value={storageBucket}
                  onChange={e => setStorageBucket(e.target.value)}
                  placeholder="unex.appspot.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5"
            >
              <Save className="w-4 h-4 text-orange-400" />
              <span>Enregistrer la configuration Firebase</span>
            </button>
          </form>

          {/* Security Rules indicator */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 space-y-1.5 text-xs">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Règles de sécurité prêtes (firestore.rules & storage.rules)</span>
            </div>
            <p className="text-[11px] text-slate-500">
              Les fichiers <code>firestore.rules</code> et <code>storage.rules</code> sont déjà générés à la racine du projet avec protection RBAC vendeur/admin et validation des prix et stocks.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

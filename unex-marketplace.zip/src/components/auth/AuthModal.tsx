import React, { useState } from 'react';
import { X, User, Store, Shield, Check, Phone, MapPin, Mail, LogOut, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { MADAGASCAR_CITIES } from '../../i18n/translations';
import { UserRole } from '../../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, allUsers, switchUser, switchRole, updateProfile, registerUser } = useAuth();
  const { t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'profile' | 'switch' | 'register'>('profile');
  
  // Profile edit fields
  const [name, setName] = useState(currentUser.name);
  const [phone, setPhone] = useState(currentUser.phone);
  const [city, setCity] = useState(currentUser.city || MADAGASCAR_CITIES[0]);
  const [address, setAddress] = useState(currentUser.address || '');
  const [shopName, setShopName] = useState(currentUser.shopName || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Register form fields
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('buyer');
  const [regShopName, setRegShopName] = useState('');

  if (!isOpen) return null;

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      phone,
      city,
      address,
      shopName: currentUser.role === 'seller' ? shopName : undefined
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regPhone.trim()) return;
    registerUser(regName, regEmail || `${regName.toLowerCase().replace(/\s+/g, '')}@unex.mg`, regPhone, regRole, regShopName);
    setActiveTab('profile');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-orange-500" />
            <h2 className="text-sm font-bold text-slate-900">Espace Utilisateur & Profil</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-slate-100 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex bg-slate-100 p-1 mx-4 mt-3 rounded-2xl border border-slate-200 text-xs">
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-1.5 rounded-xl font-bold transition text-center ${
              activeTab === 'profile' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
            }`}
          >
            Mon Profil
          </button>
          <button
            onClick={() => setActiveTab('switch')}
            className={`flex-1 py-1.5 rounded-xl font-bold transition text-center ${
              activeTab === 'switch' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
            }`}
          >
            Changer de compte
          </button>
          <button
            onClick={() => setActiveTab('register')}
            className={`flex-1 py-1.5 rounded-xl font-bold transition text-center ${
              activeTab === 'register' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
            }`}
          >
            Nouveau compte
          </button>
        </div>

        {/* Tab 1: Profile Editor */}
        {activeTab === 'profile' && (
          <form onSubmit={handleSaveProfile} className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
            {savedSuccess && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs p-2.5 rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>Profil mis à jour avec succès !</span>
              </div>
            )}

            {/* Current user badge */}
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-orange-500 text-white font-bold flex items-center justify-center">
                  {currentUser.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{currentUser.name}</h4>
                  <span className="text-[10px] text-slate-500">{currentUser.email}</span>
                </div>
              </div>

              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                currentUser.role === 'admin'
                  ? 'bg-rose-100 text-rose-800'
                  : currentUser.role === 'seller'
                  ? 'bg-orange-100 text-orange-800'
                  : 'bg-blue-100 text-blue-800'
              }`}>
                {currentUser.role.toUpperCase()}
              </span>
            </div>

            {/* Quick role change */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Changer de rôle pour tester l'application :
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['buyer', 'seller', 'admin'] as UserRole[]).map(role => (
                  <button
                    key={role}
                    type="button"
                    onClick={() => switchRole(role)}
                    className={`py-2 px-1 text-xs rounded-xl border text-center font-bold transition ${
                      currentUser.role === role
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {role === 'buyer' ? 'Acheteur' : role === 'seller' ? 'Vendeur' : 'Admin'}
                  </button>
                ))}
              </div>
            </div>

            {/* Editable Fields */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nom complet</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Téléphone mobile (Mada)</label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Ville</label>
              <select
                value={city}
                onChange={e => setCity(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs focus:outline-none focus:border-orange-500"
              >
                {MADAGASCAR_CITIES.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Adresse ou Quartier</label>
              <input
                type="text"
                value={address}
                onChange={e => setAddress(e.target.value)}
                placeholder="Ex: Lot IV B 22 Tsaralalana"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>

            {currentUser.role === 'seller' && (
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nom de votre boutique</label>
                <input
                  type="text"
                  value={shopName}
                  onChange={e => setShopName(e.target.value)}
                  placeholder="Ex: Mada High Tech"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow-md transition"
            >
              Enregistrer les modifications
            </button>
          </form>
        )}

        {/* Tab 2: Switch accounts */}
        {activeTab === 'switch' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-2.5 no-scrollbar">
            <p className="text-xs text-slate-500 mb-2">
              Basculez instantanément entre les comptes de démonstration pré-configurés :
            </p>

            {allUsers.map(u => {
              const isSelected = u.id === currentUser.id;
              return (
                <div
                  key={u.id}
                  onClick={() => switchUser(u.id)}
                  className={`p-3 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                    isSelected
                      ? 'bg-orange-50/80 border-orange-500'
                      : 'bg-white border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-slate-800 text-white font-bold text-xs flex items-center justify-center">
                      {u.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-900">{u.name}</span>
                        <span className="text-[9px] uppercase font-bold text-slate-500">
                          ({u.role})
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400">
                        {u.shopName ? `Boutique: ${u.shopName}` : u.city}
                      </p>
                    </div>
                  </div>

                  {isSelected && <Check className="w-4 h-4 text-orange-600" />}
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 3: Register new user */}
        {activeTab === 'register' && (
          <form onSubmit={handleRegister} className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nom complet *</label>
              <input
                type="text"
                required
                value={regName}
                onChange={e => setRegName(e.target.value)}
                placeholder="Ex: Rado Ranaivo"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Téléphone mobile *</label>
              <input
                type="tel"
                required
                value={regPhone}
                onChange={e => setRegPhone(e.target.value)}
                placeholder="034 XX XXX XX"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Rôle du compte *</label>
              <select
                value={regRole}
                onChange={e => setRegRole(e.target.value as UserRole)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs focus:outline-none focus:border-orange-500"
              >
                <option value="buyer">Acheteur (Client)</option>
                <option value="seller">Vendeur (Boutique marketplace)</option>
                <option value="admin">Administrateur</option>
              </select>
            </div>

            {regRole === 'seller' && (
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nom de votre boutique</label>
                <input
                  type="text"
                  value={regShopName}
                  onChange={e => setRegShopName(e.target.value)}
                  placeholder="Ex: Madagascar Artisanat & Épices"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow-md transition"
            >
              Créer mon compte Unex
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

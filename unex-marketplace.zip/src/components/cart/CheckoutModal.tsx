import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck, MapPin, Phone, CreditCard, Banknote, AlertCircle, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useMarket } from '../../context/MarketContext';
import { MADAGASCAR_CITIES } from '../../i18n/translations';
import { CartItem, Order } from '../../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  directCheckoutItem?: CartItem | null;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  directCheckoutItem,
  onOrderSuccess
}) => {
  const { t, formatMGA } = useLanguage();
  const { currentUser } = useAuth();
  const { cart, clearCart, subtotal: cartSubtotal, totalDeliveryFee: cartDeliveryFee, totalAmount: cartTotal } = useCart();
  const { createOrder, products } = useMarket();

  // If direct checkout from product page, use that; otherwise use cart
  const checkoutItems: CartItem[] = directCheckoutItem ? [directCheckoutItem] : cart;

  const directSubtotal = directCheckoutItem
    ? (directCheckoutItem.product.wholesalePrice &&
       directCheckoutItem.product.minWholesaleQty &&
       directCheckoutItem.quantity >= directCheckoutItem.product.minWholesaleQty
        ? directCheckoutItem.product.wholesalePrice
        : directCheckoutItem.product.price) * directCheckoutItem.quantity
    : 0;

  const directDeliveryFee = directCheckoutItem?.product.deliveryFee || 4000;
  const directTotal = directSubtotal + directDeliveryFee;

  const activeSubtotal = directCheckoutItem ? directSubtotal : cartSubtotal;
  const activeDeliveryFee = directCheckoutItem ? directDeliveryFee : cartDeliveryFee;
  const activeTotal = directCheckoutItem ? directTotal : cartTotal;

  const [fullName, setFullName] = useState(currentUser.name || '');
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [city, setCity] = useState(currentUser.city || MADAGASCAR_CITIES[0]);
  const [address, setAddress] = useState(currentUser.address || '');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'mvola' | 'orange_money' | 'airtel_money'>('cod');
  
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!fullName.trim()) {
      setError('Veuillez renseigner votre nom complet.');
      return;
    }
    if (!phone.trim() || phone.replace(/\D/g, '').length < 8) {
      setError('Veuillez renseigner un numéro de téléphone valide (ex: 034 12 345 67).');
      return;
    }
    if (!address.trim()) {
      setError('Veuillez renseigner une adresse ou un quartier de livraison précis.');
      return;
    }

    // Stock verification
    for (const item of checkoutItems) {
      const currentProduct = products.find(p => p.id === item.product.id);
      if (!currentProduct || currentProduct.stock < item.quantity) {
        setError(`Désolé, le stock pour "${item.product.title}" est insuffisant (reste ${currentProduct?.stock || 0}).`);
        return;
      }
    }

    setIsSubmitting(true);

    try {
      const newOrder = createOrder(
        checkoutItems,
        {
          name: fullName,
          phone,
          city,
          address,
          notes,
          paymentMethod
        },
        activeTotal,
        activeDeliveryFee
      );

      // Trigger celebration
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });

      if (!directCheckoutItem) {
        clearCart();
      }

      setConfirmedOrder(newOrder);
      setIsSubmitting(false);
      onOrderSuccess(newOrder);
    } catch {
      setError('Une erreur est survenue lors de la création de la commande.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900">
            {confirmedOrder ? 'Confirmation de commande' : t.checkout}
          </h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-slate-100 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success View */}
        {confirmedOrder ? (
          <div className="p-6 text-center space-y-4 overflow-y-auto no-scrollbar">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                Commande N° {confirmedOrder.id}
              </span>
              <h3 className="text-lg font-black text-slate-900 mt-2">
                {t.orderSuccess}
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                {t.orderSuccessSub} Un SMS et une notification vous seront envoyés au {confirmedOrder.buyerPhone}.
              </p>
            </div>

            {/* Order details box */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 text-left space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Montant total :</span>
                <span className="font-extrabold text-orange-600 text-sm">
                  {formatMGA(confirmedOrder.totalAmount)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Mode de paiement :</span>
                <span className="font-semibold text-slate-800 uppercase">
                  {confirmedOrder.paymentMethod === 'cod' ? 'Paiement à la livraison' : confirmedOrder.paymentMethod}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Destination :</span>
                <span className="font-semibold text-slate-800 text-right">
                  {confirmedOrder.buyerCity} - {confirmedOrder.deliveryAddress}
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition"
            >
              Fermer et continuer mes achats
            </button>
          </div>
        ) : (
          /* Checkout Form View */
          <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
              {error && (
                <div className="bg-rose-50 border border-rose-200 text-rose-700 text-xs p-3 rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Delivery Coordinates Section */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5 uppercase tracking-wide">
                  <MapPin className="w-3.5 h-3.5 text-orange-500" />
                  <span>{t.deliveryAddress}</span>
                </h3>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                    {t.fullName} *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    placeholder="Ex: Faly Rakoto"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                      Téléphone mobile *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      placeholder="034 XX XXX XX"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                      {t.selectCity} *
                    </label>
                    <select
                      value={city}
                      onChange={e => setCity(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs focus:outline-none focus:border-orange-500"
                    >
                      {MADAGASCAR_CITIES.map(c => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                    Adresse précise (Quartier, Rue, Lot) *
                  </label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={e => setAddress(e.target.value)}
                    placeholder={t.addressPlaceholder}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                    {t.orderNotes}
                  </label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="Repères, heure idéale de livraison..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500 resize-none"
                  />
                </div>
              </div>

              {/* Payment Methods */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5 uppercase tracking-wide">
                  <CreditCard className="w-3.5 h-3.5 text-orange-500" />
                  <span>{t.paymentMethod}</span>
                </h3>

                <div className="space-y-2">
                  {[
                    {
                      id: 'cod',
                      label: t.paymentCod,
                      desc: 'Réglez en espèces directement au livreur à la réception',
                      badge: 'Populaire à Mada',
                      icon: Banknote
                    },
                    {
                      id: 'mvola',
                      label: t.paymentMvola,
                      desc: 'Paiement par téléphone Telma Money',
                      badge: 'Mobile Money',
                      icon: Phone
                    },
                    {
                      id: 'orange_money',
                      label: t.paymentOrange,
                      desc: 'Paiement Orange Money Madagascar',
                      badge: 'Mobile Money',
                      icon: Phone
                    },
                    {
                      id: 'airtel_money',
                      label: t.paymentAirtel,
                      desc: 'Paiement Airtel Money Madagascar',
                      badge: 'Mobile Money',
                      icon: Phone
                    }
                  ].map(method => {
                    const isSelected = paymentMethod === method.id;
                    const Icon = method.icon;
                    return (
                      <label
                        key={method.id}
                        className={`flex items-start gap-3 p-3 rounded-2xl border cursor-pointer transition ${
                          isSelected
                            ? 'bg-orange-50/70 border-orange-500 ring-1 ring-orange-400'
                            : 'bg-white border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name="payment"
                          checked={isSelected}
                          onChange={() => setPaymentMethod(method.id as any)}
                          className="mt-1 accent-orange-500"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-slate-900">
                              {method.label}
                            </span>
                            <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium">
                              {method.badge}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {method.desc}
                          </p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Order Recap */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/70 space-y-1.5 text-xs">
                <span className="font-bold text-slate-800 block mb-1">
                  {t.orderSummary} ({checkoutItems.length} articles)
                </span>
                <div className="flex justify-between text-slate-600">
                  <span>{t.subtotal}</span>
                  <span className="font-semibold">{formatMGA(activeSubtotal)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>{t.deliveryFee}</span>
                  <span className="font-semibold">
                    {activeDeliveryFee > 0 ? formatMGA(activeDeliveryFee) : t.freeDelivery}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-black text-slate-900 pt-1.5 border-t border-slate-200">
                  <span>Total à régler :</span>
                  <span className="text-orange-600">{formatMGA(activeTotal)}</span>
                </div>
              </div>
            </div>

            {/* Bottom Submit Action */}
            <div className="p-3 bg-white border-t border-slate-100">
              <button
                type="submit"
                disabled={isSubmitting || checkoutItems.length === 0}
                className="w-full py-3 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 transition active:scale-98 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Validation en cours...</span>
                ) : (
                  <>
                    <span>Confirmer la commande ({formatMGA(activeTotal)})</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

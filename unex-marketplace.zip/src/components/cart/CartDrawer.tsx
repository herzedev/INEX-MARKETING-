import React from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, Tag } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useCart } from '../../context/CartContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  onProceedToCheckout
}) => {
  const { t, formatMGA } = useLanguage();
  const {
    cart,
    removeFromCart,
    updateQuantity,
    clearCart,
    subtotal,
    totalDeliveryFee,
    totalAmount
  } = useCart();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
      <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-orange-500" />
            <h2 className="text-sm font-bold text-slate-900">{t.cart} ({cart.length})</h2>
          </div>
          <div className="flex items-center gap-2">
            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="text-xs text-rose-500 hover:text-rose-600 font-medium px-2 py-1 rounded"
              >
                Vider
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-full hover:bg-slate-100 text-slate-500"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-3">
                <ShoppingBag className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-sm font-bold text-slate-700">{t.cartEmpty}</p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">{t.cartEmptySub}</p>
              <button
                onClick={onClose}
                className="mt-4 px-4 py-2 bg-orange-500 text-white rounded-xl text-xs font-bold hover:bg-orange-600 transition"
              >
                Découvrir les produits
              </button>
            </div>
          ) : (
            cart.map(item => {
              const isWholesaleApplied =
                item.product.wholesalePrice &&
                item.product.minWholesaleQty &&
                item.quantity >= item.product.minWholesaleQty;

              const activePrice = isWholesaleApplied
                ? item.product.wholesalePrice!
                : item.product.price;

              return (
                <div
                  key={item.product.id}
                  className="bg-slate-50 p-3 rounded-2xl border border-slate-200/70 flex gap-3 items-center"
                >
                  {/* Thumbnail */}
                  <img
                    src={item.product.images[0]}
                    alt={item.product.title}
                    className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0 bg-white"
                  />

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-semibold text-slate-800 line-clamp-1">
                      {item.product.title}
                    </h4>

                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Vendeur: <span className="font-medium text-slate-700">{item.product.sellerName}</span>
                    </div>

                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs font-extrabold text-slate-900">
                        {formatMGA(activePrice)}
                      </span>
                      {isWholesaleApplied && (
                        <span className="text-[10px] bg-orange-100 text-orange-700 font-bold px-1.5 py-0.2 rounded flex items-center gap-0.5">
                          <Tag className="w-2.5 h-2.5" /> Gros
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Quantity and Remove */}
                  <div className="flex flex-col items-end justify-between self-stretch">
                    <button
                      onClick={() => removeFromCart(item.product.id)}
                      className="text-slate-400 hover:text-rose-500 transition p-1"
                      title="Supprimer l'article"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg p-0.5">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold text-slate-600 hover:bg-slate-100 active:scale-95"
                      >
                        -
                      </button>
                      <span className="text-xs font-bold text-slate-800 w-4 text-center">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        disabled={item.quantity >= item.product.stock}
                        className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold text-slate-600 hover:bg-slate-100 active:scale-95 disabled:opacity-40"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {cart.length > 0 && (
          <div className="p-4 border-t border-slate-100 bg-white space-y-3">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-500">
                <span>{t.subtotal}</span>
                <span className="font-semibold text-slate-800">{formatMGA(subtotal)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>{t.deliveryFee}</span>
                <span className="font-semibold text-slate-800">
                  {totalDeliveryFee > 0 ? formatMGA(totalDeliveryFee) : t.freeDelivery}
                </span>
              </div>
              <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-1.5 border-t border-slate-100">
                <span>{t.total}</span>
                <span className="text-orange-600 text-base">{formatMGA(totalAmount)}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-[11px] text-slate-500 bg-slate-50 p-2 rounded-xl">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Garantie Unex : Colis vérifié avant validation du paiement.</span>
            </div>

            <button
              onClick={() => {
                onClose();
                onProceedToCheckout();
              }}
              className="w-full py-3 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 transition active:scale-98"
            >
              <span>{t.checkout}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

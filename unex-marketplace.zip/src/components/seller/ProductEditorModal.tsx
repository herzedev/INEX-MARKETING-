import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Image as ImageIcon, Sparkles, AlertCircle } from 'lucide-react';
import { Product, ProductCategory } from '../../types';
import { CATEGORIES } from '../../i18n/translations';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';

interface ProductEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  productToEdit?: Product | null;
  onSave: (productData: any) => void;
}

export const ProductEditorModal: React.FC<ProductEditorModalProps> = ({
  isOpen,
  onClose,
  productToEdit,
  onSave
}) => {
  const { language, t } = useLanguage();
  const { currentUser } = useAuth();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ProductCategory>('telephones');
  const [price, setPrice] = useState<number>(50000);
  const [wholesalePrice, setWholesalePrice] = useState<number | undefined>(undefined);
  const [minWholesaleQty, setMinWholesaleQty] = useState<number | undefined>(undefined);
  const [stock, setStock] = useState<number>(10);
  const [deliveryFee, setDeliveryFee] = useState<number>(4000);
  const [imageUrl, setImageUrl] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (productToEdit) {
      setTitle(productToEdit.title);
      setDescription(productToEdit.description);
      setCategory(productToEdit.category);
      setPrice(productToEdit.price);
      setWholesalePrice(productToEdit.wholesalePrice);
      setMinWholesaleQty(productToEdit.minWholesaleQty);
      setStock(productToEdit.stock);
      setDeliveryFee(productToEdit.deliveryFee);
      setImages(productToEdit.images || []);
    } else {
      setTitle('');
      setDescription('');
      setCategory('telephones');
      setPrice(50000);
      setWholesalePrice(undefined);
      setMinWholesaleQty(undefined);
      setStock(10);
      setDeliveryFee(4000);
      setImages([
        'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=80'
      ]);
    }
  }, [productToEdit, isOpen]);

  if (!isOpen) return null;

  const handleAddImage = () => {
    if (imageUrl.trim()) {
      setImages(prev => [...prev, imageUrl.trim()]);
      setImageUrl('');
    }
  };

  const handleRemoveImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!title.trim()) {
      setError('Veuillez renseigner un titre de produit.');
      return;
    }
    if (price <= 0) {
      setError('Le prix doit être supérieur à 0 MGA.');
      return;
    }
    if (stock < 0) {
      setError('Le stock ne peut pas être négatif.');
      return;
    }
    if (images.length === 0) {
      setError('Veuillez ajouter au moins une image pour le produit.');
      return;
    }

    onSave({
      title,
      description,
      category,
      price: Number(price),
      wholesalePrice: wholesalePrice ? Number(wholesalePrice) : undefined,
      minWholesaleQty: minWholesaleQty ? Number(minWholesaleQty) : undefined,
      stock: Number(stock),
      deliveryFee: Number(deliveryFee),
      images,
      sellerId: currentUser.id,
      sellerName: currentUser.shopName || currentUser.name,
      sellerPhone: currentUser.phone,
      sellerWhatsapp: currentUser.whatsapp || currentUser.phone.replace(/\D/g, ''),
      sellerCity: currentUser.city || 'Antananarivo',
      status: 'active'
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900">
            {productToEdit ? t.editProduct : t.addProduct}
          </h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-slate-100 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
            {error && (
              <div className="bg-rose-50 border border-rose-200 text-rose-700 text-xs p-3 rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Title */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Titre du produit *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Ex: Écouteurs Sans Fil Pro V5.3..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>

            {/* Category */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Catégorie *
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as ProductCategory)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat.id} value={cat.id}>
                    {cat.label[language]}
                  </option>
                ))}
              </select>
            </div>

            {/* Price & Stock */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Prix unitaire (MGA) *
                </label>
                <input
                  type="number"
                  min="500"
                  step="500"
                  required
                  value={price}
                  onChange={e => setPrice(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500 font-bold"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Stock disponible *
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={stock}
                  onChange={e => setStock(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500 font-bold"
                />
              </div>
            </div>

            {/* Wholesale Pricing (Inspired by Alibaba B2B/B2C) */}
            <div className="bg-orange-50/70 p-3 rounded-2xl border border-orange-200 space-y-2">
              <span className="text-xs font-bold text-orange-950 block">
                Paliers de Gros (Optionnel - style Alibaba)
              </span>
              <p className="text-[11px] text-orange-800">
                Offrez un rabais aux acheteurs qui commandent en gros volume.
              </p>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-semibold text-slate-700 block mb-1">
                    Prix de gros unitaire (MGA)
                  </label>
                  <input
                    type="number"
                    min="500"
                    step="500"
                    value={wholesalePrice || ''}
                    onChange={e =>
                      setWholesalePrice(e.target.value ? Number(e.target.value) : undefined)
                    }
                    placeholder="Ex: 45000"
                    className="w-full bg-white border border-orange-200 rounded-xl px-2.5 py-1.5 text-xs focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-semibold text-slate-700 block mb-1">
                    Quantité minimum de gros
                  </label>
                  <input
                    type="number"
                    min="2"
                    value={minWholesaleQty || ''}
                    onChange={e =>
                      setMinWholesaleQty(e.target.value ? Number(e.target.value) : undefined)
                    }
                    placeholder="Ex: 5"
                    className="w-full bg-white border border-orange-200 rounded-xl px-2.5 py-1.5 text-xs focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>
            </div>

            {/* Delivery fee */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Frais de livraison estimés (MGA)
              </label>
              <input
                type="number"
                min="0"
                step="500"
                value={deliveryFee}
                onChange={e => setDeliveryFee(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>

            {/* Images Management */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Photos du produit ({images.length}) *
              </label>

              <div className="flex gap-2 mb-2">
                <input
                  type="url"
                  value={imageUrl}
                  onChange={e => setImageUrl(e.target.value)}
                  placeholder="Collez une URL d'image (ex: Unsplash)..."
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
                />
                <button
                  type="button"
                  onClick={handleAddImage}
                  className="px-3 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl"
                >
                  Ajouter
                </button>
              </div>

              {/* Thumbnails preview */}
              <div className="flex gap-2 flex-wrap">
                {images.map((img, idx) => (
                  <div key={idx} className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-200 group">
                    <img src={img} alt="" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(idx)}
                      className="absolute top-1 right-1 bg-rose-600 text-white rounded-full p-1 opacity-90 hover:opacity-100"
                    >
                      <Trash2 className="w-2.5 h-2.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                Description détaillée du produit
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Caractéristiques techniques, garantie, état, compatibilité..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          {/* Footer Submit */}
          <div className="p-3 bg-white border-t border-slate-100">
            <button
              type="submit"
              className="w-full py-3 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow-md transition"
            >
              {productToEdit ? 'Enregistrer les modifications' : 'Publier le produit sur Unex'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

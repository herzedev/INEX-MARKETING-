import React, { useState } from 'react';
import {
  Plus,
  Package,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  Edit2,
  Trash2,
  CheckCircle,
  Truck,
  XCircle,
  Phone,
  MessageCircle,
  Store,
  MapPin,
  ExternalLink
} from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useMarket } from '../../context/MarketContext';
import { Product, Order, OrderStatus } from '../../types';
import { ProductEditorModal } from './ProductEditorModal';

interface SellerDashboardProps {
  onOpenChatWithBuyer: (buyerId: string, buyerName: string) => void;
}

export const SellerDashboard: React.FC<SellerDashboardProps> = ({
  onOpenChatWithBuyer
}) => {
  const { t, formatMGA } = useLanguage();
  const { currentUser } = useAuth();
  const {
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    sellerOrders,
    updateOrderStatus
  } = useMarket();

  const [activeTab, setActiveTab] = useState<'products' | 'orders'>('products');
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [productEditing, setProductEditing] = useState<Product | null>(null);

  // Filter seller's own products
  const myProducts = products.filter(p => p.sellerId === currentUser.id);

  // Compute seller metrics
  const totalRevenue = sellerOrders
    .filter(o => o.status !== 'cancelled')
    .reduce((sum, o) => {
      const myItemsTotal = o.items
        .filter(i => i.sellerId === currentUser.id)
        .reduce((iSum, i) => iSum + i.price * i.quantity, 0);
      return sum + myItemsTotal;
    }, 0);

  const pendingOrdersCount = sellerOrders.filter(o => o.status === 'pending').length;
  const lowStockCount = myProducts.filter(p => p.stock <= 3).length;

  const handleOpenAdd = () => {
    setProductEditing(null);
    setIsEditorOpen(true);
  };

  const handleOpenEdit = (p: Product) => {
    setProductEditing(p);
    setIsEditorOpen(true);
  };

  const handleSaveProduct = (data: any) => {
    if (productEditing) {
      updateProduct(productEditing.id, data);
    } else {
      addProduct(data);
    }
  };

  const handleWhatsAppBuyer = (phone: string, orderId: string, buyerName: string) => {
    const cleanPhone = phone.replace(/\D/g, '');
    const internationalPhone = cleanPhone.startsWith('0')
      ? `261${cleanPhone.substring(1)}`
      : cleanPhone;
    const msg = encodeURIComponent(
      `Bonjour ${buyerName}, nous préparons votre commande Unex ${orderId}. Nous vous contactons pour convenir de la livraison.`
    );
    window.open(`https://wa.me/${internationalPhone}?text=${msg}`, '_blank');
  };

  return (
    <div className="p-4 space-y-4">
      {/* Seller Boutique Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-4 shadow-xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white font-black text-lg shadow-md">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-sm font-black text-white">
                  {currentUser.shopName || currentUser.name}
                </h1>
                <CheckCircle className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />
              </div>
              <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3 text-slate-400" />
                {currentUser.city || 'Antananarivo'}
              </p>
            </div>
          </div>

          <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-2 py-1 rounded-full border border-emerald-500/30">
            Boutique Active
          </span>
        </div>

        {/* 4 Quick KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-800">
          <div className="bg-slate-800/80 p-2.5 rounded-2xl border border-slate-700/60">
            <span className="text-[10px] text-slate-400 block font-medium">Revenu généré</span>
            <span className="text-xs font-black text-emerald-400 block truncate">
              {formatMGA(totalRevenue)}
            </span>
          </div>

          <div className="bg-slate-800/80 p-2.5 rounded-2xl border border-slate-700/60">
            <span className="text-[10px] text-slate-400 block font-medium">Commandes</span>
            <span className="text-xs font-black text-white block">
              {sellerOrders.length}
            </span>
          </div>

          <div className="bg-slate-800/80 p-2.5 rounded-2xl border border-slate-700/60">
            <span className="text-[10px] text-slate-400 block font-medium">En attente</span>
            <span className={`text-xs font-black block ${pendingOrdersCount > 0 ? 'text-orange-400' : 'text-white'}`}>
              {pendingOrdersCount}
            </span>
          </div>

          <div className="bg-slate-800/80 p-2.5 rounded-2xl border border-slate-700/60">
            <span className="text-[10px] text-slate-400 block font-medium">Produits actifs</span>
            <span className="text-xs font-black text-white block">
              {myProducts.length}
            </span>
          </div>
        </div>
      </div>

      {/* Sub Tabs: Mes Produits & Commandes Reçues */}
      <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl border border-slate-200">
        <button
          onClick={() => setActiveTab('products')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
            activeTab === 'products'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Package className="w-3.5 h-3.5 text-orange-500" />
          <span>{t.myProducts} ({myProducts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
            activeTab === 'orders'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5 text-orange-500" />
          <span>Commandes reçues ({sellerOrders.length})</span>
          {pendingOrdersCount > 0 && (
            <span className="bg-orange-500 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full">
              {pendingOrdersCount}
            </span>
          )}
        </button>
      </div>

      {/* 1. Tab: Mes Produits */}
      {activeTab === 'products' && (
        <div className="space-y-3">
          {/* Add product button */}
          <button
            onClick={handleOpenAdd}
            className="w-full py-3 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 text-white font-extrabold text-xs rounded-2xl shadow-md flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addProduct}</span>
          </button>

          {myProducts.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center text-slate-400 space-y-2">
              <Package className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="text-xs font-semibold text-slate-700">Vous n'avez pas encore publié de produit.</p>
              <p className="text-[11px] text-slate-400">Cliquez sur le bouton ci-dessus pour ajouter votre premier article !</p>
            </div>
          ) : (
            myProducts.map(p => (
              <div
                key={p.id}
                className="bg-white rounded-2xl border border-slate-200/80 p-3 flex gap-3 items-center shadow-xs hover:shadow-md transition"
              >
                <img
                  src={p.images[0]}
                  alt={p.title}
                  className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0"
                />

                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-slate-900 line-clamp-1">
                    {p.title}
                  </h4>

                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs font-extrabold text-orange-600">
                      {formatMGA(p.price)}
                    </span>
                    {p.wholesalePrice && (
                      <span className="text-[10px] bg-orange-100 text-orange-800 px-1.5 py-0.2 rounded font-semibold">
                        Gros : {formatMGA(p.wholesalePrice)}
                      </span>
                    )}
                  </div>

                  {/* Stock adjuster */}
                  <div className="flex items-center gap-2 mt-1.5 text-[11px]">
                    <span className="text-slate-500">Stock :</span>
                    <button
                      onClick={() => updateProduct(p.id, { stock: Math.max(0, p.stock - 1) })}
                      className="w-5 h-5 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold flex items-center justify-center"
                    >
                      -
                    </button>
                    <span className={`font-bold ${p.stock <= 3 ? 'text-rose-600' : 'text-slate-800'}`}>
                      {p.stock}
                    </span>
                    <button
                      onClick={() => updateProduct(p.id, { stock: p.stock + 1 })}
                      className="w-5 h-5 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold flex items-center justify-center"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Edit & Delete */}
                <div className="flex flex-col gap-1.5 shrink-0">
                  <button
                    onClick={() => handleOpenEdit(p)}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                    title="Modifier"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteProduct(p.id)}
                    className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 transition"
                    title="Supprimer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* 2. Tab: Commandes Reçues */}
      {activeTab === 'orders' && (
        <div className="space-y-3">
          {sellerOrders.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center text-slate-400 space-y-2">
              <Package className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="text-xs font-semibold text-slate-700">Aucune commande reçue pour l'instant.</p>
              <p className="text-[11px] text-slate-400">Vos commandes clients apparaîtront ici avec les coordonnées pour expédition.</p>
            </div>
          ) : (
            sellerOrders.map(order => {
              const myItems = order.items.filter(i => i.sellerId === currentUser.id);
              const orderSubtotal = myItems.reduce((s, i) => s + i.price * i.quantity, 0);

              return (
                <div
                  key={order.id}
                  className="bg-white rounded-2xl border border-slate-200 p-3.5 space-y-3 shadow-xs"
                >
                  {/* Header */}
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <div>
                      <span className="text-xs font-extrabold text-slate-900 block">
                        {order.id}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        Client : <strong className="text-slate-700">{order.buyerName}</strong>
                      </span>
                    </div>

                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        order.status === 'pending'
                          ? 'bg-amber-100 text-amber-800'
                          : order.status === 'confirmed'
                          ? 'bg-blue-100 text-blue-800'
                          : order.status === 'shipped'
                          ? 'bg-purple-100 text-purple-800'
                          : order.status === 'delivered'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {order.status.toUpperCase()}
                    </span>
                  </div>

                  {/* Items */}
                  <div className="space-y-1.5">
                    {myItems.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs">
                        <span className="text-slate-700 truncate max-w-[200px]">
                          {item.quantity}× {item.title}
                        </span>
                        <span className="font-bold text-slate-900">
                          {formatMGA(item.price * item.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Buyer Contact & Address */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/60 space-y-1 text-[11px] text-slate-600">
                    <p className="flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400" />
                      <span>Tél : <strong>{order.buyerPhone}</strong></span>
                    </p>
                    <p className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>Livraison : {order.buyerCity} ({order.deliveryAddress})</span>
                    </p>
                    {order.notes && (
                      <p className="text-slate-500 italic">Note : {order.notes}</p>
                    )}
                  </div>

                  {/* Actions for Seller */}
                  <div className="flex items-center justify-between pt-1 gap-2">
                    {/* Buyer Contact via WhatsApp / Message */}
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() =>
                          handleWhatsAppBuyer(
                            order.buyerPhone,
                            order.id,
                            order.buyerName
                          )
                        }
                        className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-medium flex items-center gap-1 transition"
                        title="Contacter sur WhatsApp"
                      >
                        <Phone className="w-3 h-3" />
                        <span className="text-[10px]">WhatsApp</span>
                      </button>

                      <button
                        onClick={() =>
                          onOpenChatWithBuyer(order.buyerId, order.buyerName)
                        }
                        className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1 transition"
                        title="Chat interne"
                      >
                        <MessageCircle className="w-3 h-3 text-orange-500" />
                      </button>
                    </div>

                    {/* Order Workflow buttons */}
                    <div className="flex items-center gap-1.5">
                      {order.status === 'pending' && (
                        <>
                          <button
                            onClick={() => updateOrderStatus(order.id, 'cancelled')}
                            className="text-[11px] font-semibold text-rose-600 hover:bg-rose-50 px-2 py-1 rounded"
                          >
                            Refuser
                          </button>
                          <button
                            onClick={() => updateOrderStatus(order.id, 'confirmed')}
                            className="text-[11px] font-bold bg-blue-600 hover:bg-blue-700 text-white px-2.5 py-1 rounded-lg shadow-xs"
                          >
                            Accepter
                          </button>
                        </>
                      )}

                      {order.status === 'confirmed' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'shipped')}
                          className="text-[11px] font-bold bg-purple-600 hover:bg-purple-700 text-white px-2.5 py-1 rounded-lg shadow-xs flex items-center gap-1"
                        >
                          <Truck className="w-3 h-3" />
                          <span>Expédier</span>
                        </button>
                      )}

                      {order.status === 'shipped' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'delivered')}
                          className="text-[11px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-lg shadow-xs flex items-center gap-1"
                        >
                          <CheckCircle className="w-3 h-3" />
                          <span>Marquer Livrée</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Product Editor Modal */}
      <ProductEditorModal
        isOpen={isEditorOpen}
        onClose={() => setIsEditorOpen(false)}
        productToEdit={productEditing}
        onSave={handleSaveProduct}
      />
    </div>
  );
};

import React from 'react';
import { Search, SlidersHorizontal, ShoppingBag, Globe, Shield, Store, User, Zap } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useMarket } from '../../context/MarketContext';
import { Language, UserRole } from '../../types';

interface HeaderProps {
  onOpenFilter: () => void;
  onOpenCart: () => void;
  onOpenAuth: () => void;
  onOpenFirebaseConfig: () => void;
  onOpenApkGuide: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenFilter,
  onOpenCart,
  onOpenAuth,
  onOpenFirebaseConfig,
  onOpenApkGuide
}) => {
  const { t, language, setLanguage } = useLanguage();
  const { currentUser, switchRole } = useAuth();
  const { cartCount } = useCart();
  const { filters, setFilters } = useMarket();

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters(prev => ({ ...prev, searchQuery: e.target.value }));
  };

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
  };

  // Count active non-default filters
  const activeFiltersCount =
    (filters.category !== 'all' ? 1 : 0) +
    (filters.minPrice > 0 || filters.maxPrice < 3000000 ? 1 : 0) +
    (filters.inStockOnly ? 1 : 0) +
    (filters.city !== 'all' ? 1 : 0);

  return (
    <header className="sticky top-0 z-30 bg-slate-900 text-white shadow-md border-b border-slate-800">
      {/* Top Banner with Role Switcher & Language */}
      <div className="bg-slate-950 px-3.5 py-1.5 flex items-center justify-between text-xs border-b border-slate-800/80">
        {/* Role Quick Selector */}
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] text-slate-400 font-medium">Mode:</span>
          <div className="inline-flex rounded-lg bg-slate-800/80 p-0.5 border border-slate-700/60">
            {(['buyer', 'seller', 'admin'] as UserRole[]).map((r) => {
              const isActive = currentUser.role === r;
              const labels = {
                buyer: 'Client',
                seller: 'Vendeur',
                admin: 'Admin'
              };
              return (
                <button
                  key={r}
                  onClick={() => switchRole(r)}
                  className={`px-2 py-0.5 rounded-md text-[10px] font-semibold transition ${
                    isActive
                      ? 'bg-orange-500 text-white shadow'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  {labels[r]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right tools: Language & Firebase Guide */}
        <div className="flex items-center gap-2">
          {/* APK Guide button */}
          <button
            onClick={onOpenApkGuide}
            className="text-[10px] font-medium text-orange-400 hover:text-orange-300 flex items-center gap-1 bg-orange-950/40 px-1.5 py-0.5 rounded border border-orange-800/50"
            title="Guide Export APK Android"
          >
            <span>📱 APK</span>
          </button>

          {/* Firebase Settings */}
          <button
            onClick={onOpenFirebaseConfig}
            className="text-[10px] text-slate-400 hover:text-slate-200 flex items-center gap-1 bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700"
            title="Configuration Firebase"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>Firebase</span>
          </button>

          {/* Language selector */}
          <div className="flex items-center gap-1 bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
            <Globe className="w-3 h-3 text-slate-400" />
            <select
              value={language}
              onChange={(e) => handleLanguageChange(e.target.value as Language)}
              className="bg-transparent text-[10px] font-bold text-slate-200 outline-none cursor-pointer"
            >
              <option value="fr" className="bg-slate-900 text-white">FR</option>
              <option value="mg" className="bg-slate-900 text-white">MG</option>
              <option value="en" className="bg-slate-900 text-white">EN</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Header Row */}
      <div className="px-3.5 pt-2.5 pb-2 flex items-center justify-between gap-2.5">
        {/* Brand Logo */}
        <div className="flex items-center gap-2 select-none">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-orange-600 via-orange-500 to-amber-400 flex items-center justify-center shadow-lg shadow-orange-500/20 text-white font-extrabold text-xl tracking-tighter">
            <span>U</span>
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-orange-200 bg-clip-text text-transparent">
                UNEX
              </span>
              <span className="text-[10px] font-extrabold bg-orange-500 text-white px-1.5 py-0.2 rounded tracking-wide">
                MADA
              </span>
            </div>
            <p className="text-[9px] text-slate-400 font-medium leading-none -mt-0.5">
              Wholesale & Retail
            </p>
          </div>
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2">
          {/* User Profile Avatar / Switch */}
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-1.5 bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded-full py-1 px-2 text-slate-200 text-xs transition"
          >
            {currentUser.avatar ? (
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-5 h-5 rounded-full object-cover"
              />
            ) : (
              <div className="w-5 h-5 rounded-full bg-orange-600 flex items-center justify-center text-[10px] font-bold text-white">
                {currentUser.name.charAt(0)}
              </div>
            )}
            <span className="text-[11px] font-medium max-w-[80px] truncate hidden sm:inline">
              {currentUser.name.split(' ')[0]}
            </span>
          </button>

          {/* Cart Icon with Counter */}
          <button
            onClick={onOpenCart}
            className="relative p-2 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-white transition cursor-pointer"
            aria-label="Panier"
          >
            <ShoppingBag className="w-5 h-5 text-orange-400" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-[10px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center animate-bounce shadow">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Search & Filter Row */}
      <div className="px-3.5 pb-2.5 flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={filters.searchQuery}
            onChange={handleSearchChange}
            placeholder={t.searchPlaceholder}
            className="w-full bg-slate-800/90 text-sm text-white placeholder-slate-400 rounded-xl pl-9 pr-3 py-2 border border-slate-700 focus:outline-none focus:border-orange-500 transition"
          />
          {filters.searchQuery && (
            <button
              onClick={() => setFilters(prev => ({ ...prev, searchQuery: '' }))}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
            >
              ✕
            </button>
          )}
        </div>

        {/* Filter Trigger Button */}
        <button
          onClick={onOpenFilter}
          className={`relative p-2 rounded-xl border flex items-center justify-center transition cursor-pointer ${
            activeFiltersCount > 0
              ? 'bg-orange-500 text-white border-orange-400 shadow-md'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
          }`}
          title="Filtres avancés"
        >
          <SlidersHorizontal className="w-4 h-4" />
          {activeFiltersCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-white text-orange-600 font-bold text-[9px] w-3.5 h-3.5 rounded-full flex items-center justify-center shadow">
              {activeFiltersCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
};

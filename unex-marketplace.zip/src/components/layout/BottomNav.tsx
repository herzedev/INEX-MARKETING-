import React from 'react';
import { Home, Grid, Heart, Package, User, Store, Shield } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useCart } from '../../context/CartContext';
import { useMarket } from '../../context/MarketContext';
import { useAuth } from '../../context/AuthContext';

export type NavTab = 'home' | 'categories' | 'favorites' | 'orders' | 'profile' | 'seller' | 'admin';

interface BottomNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const { t } = useLanguage();
  const { favorites } = useCart();
  const { userOrders, sellerOrders } = useMarket();
  const { currentUser } = useAuth();

  const isSeller = currentUser.role === 'seller';
  const isAdmin = currentUser.role === 'admin';

  return (
    <nav className="sticky bottom-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-lg px-2 py-1.5 flex items-center justify-around select-none">
      {/* 1. Home */}
      <button
        onClick={() => onTabChange('home')}
        className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
          activeTab === 'home'
            ? 'text-orange-600 font-bold'
            : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Home className={`w-5 h-5 transition-transform ${activeTab === 'home' ? 'scale-110 text-orange-600' : ''}`} />
        <span className="text-[10px] mt-0.5 tracking-tight">{t.navHome}</span>
      </button>

      {/* 2. Categories */}
      <button
        onClick={() => onTabChange('categories')}
        className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
          activeTab === 'categories'
            ? 'text-orange-600 font-bold'
            : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Grid className={`w-5 h-5 transition-transform ${activeTab === 'categories' ? 'scale-110 text-orange-600' : ''}`} />
        <span className="text-[10px] mt-0.5 tracking-tight">{t.navCategories}</span>
      </button>

      {/* 3. Favorites */}
      <button
        onClick={() => onTabChange('favorites')}
        className={`relative flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
          activeTab === 'favorites'
            ? 'text-orange-600 font-bold'
            : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <div className="relative">
          <Heart className={`w-5 h-5 transition-transform ${activeTab === 'favorites' ? 'scale-110 text-orange-600 fill-orange-600' : ''}`} />
          {favorites.length > 0 && (
            <span className="absolute -top-1 -right-2 bg-rose-500 text-white text-[9px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center">
              {favorites.length}
            </span>
          )}
        </div>
        <span className="text-[10px] mt-0.5 tracking-tight">{t.navFavorites}</span>
      </button>

      {/* 4. Orders */}
      <button
        onClick={() => onTabChange('orders')}
        className={`relative flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
          activeTab === 'orders'
            ? 'text-orange-600 font-bold'
            : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <div className="relative">
          <Package className={`w-5 h-5 transition-transform ${activeTab === 'orders' ? 'scale-110 text-orange-600' : ''}`} />
          {userOrders.length > 0 && (
            <span className="absolute -top-1 -right-2 bg-blue-600 text-white text-[9px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center">
              {userOrders.length}
            </span>
          )}
        </div>
        <span className="text-[10px] mt-0.5 tracking-tight">{t.navOrders}</span>
      </button>

      {/* 5. Role-Specific Tab: Seller Hub if seller, Admin if admin, else Profile */}
      {isSeller ? (
        <button
          onClick={() => onTabChange('seller')}
          className={`relative flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
            activeTab === 'seller'
              ? 'text-orange-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <div className="relative">
            <Store className={`w-5 h-5 transition-transform ${activeTab === 'seller' ? 'scale-110 text-orange-600' : ''}`} />
            {sellerOrders.filter(o => o.status === 'pending').length > 0 && (
              <span className="absolute -top-1 -right-2 bg-orange-500 text-white text-[9px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center animate-pulse">
                {sellerOrders.filter(o => o.status === 'pending').length}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">Vendeur</span>
        </button>
      ) : isAdmin ? (
        <button
          onClick={() => onTabChange('admin')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
            activeTab === 'admin'
              ? 'text-orange-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Shield className={`w-5 h-5 transition-transform ${activeTab === 'admin' ? 'scale-110 text-orange-600' : ''}`} />
          <span className="text-[10px] mt-0.5 tracking-tight">Admin</span>
        </button>
      ) : (
        <button
          onClick={() => onTabChange('profile')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
            activeTab === 'profile'
              ? 'text-orange-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <User className={`w-5 h-5 transition-transform ${activeTab === 'profile' ? 'scale-110 text-orange-600' : ''}`} />
          <span className="text-[10px] mt-0.5 tracking-tight">{t.navProfile}</span>
        </button>
      )}
    </nav>
  );
};

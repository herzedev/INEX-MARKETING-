import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Signal, Smartphone, Monitor } from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
  isFrameMode: boolean;
  onToggleFrame: () => void;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  isFrameMode,
  onToggleFrame
}) => {
  const [time, setTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  if (!isFrameMode) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center">
        {/* Top Desktop bar with Frame toggle */}
        <div className="w-full bg-slate-950/80 backdrop-blur border-b border-slate-800 text-xs px-4 py-2 flex items-center justify-between text-slate-400 z-50">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-semibold text-slate-200">Unex Marketplace</span>
            <span className="hidden sm:inline text-slate-500">|</span>
            <span className="hidden sm:inline text-slate-400">Mode Plein Écran Web</span>
          </div>
          <button
            onClick={onToggleFrame}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-orange-400 transition cursor-pointer text-xs font-medium"
            title="Activer le cadre Smartphone Android"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Vue Simulateur Android</span>
          </button>
        </div>
        <div className="w-full max-w-md md:max-w-xl lg:max-w-2xl flex-1 flex flex-col bg-slate-50 shadow-2xl relative">
          {children}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 py-4 px-2 sm:px-4 flex flex-col items-center justify-center">
      {/* Frame Control Switch */}
      <div className="mb-3 flex items-center gap-3 bg-slate-900 border border-slate-800 px-3.5 py-1.5 rounded-full shadow-lg">
        <span className="text-xs text-slate-300 font-medium flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          Simulateur Android (Appli Mobile Unex)
        </span>
        <button
          onClick={onToggleFrame}
          className="flex items-center gap-1 text-xs text-orange-400 hover:text-orange-300 transition font-medium"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Passer en Plein Écran</span>
        </button>
      </div>

      {/* Android Device Mockup */}
      <div className="relative w-full max-w-[400px] h-[840px] max-h-[92vh] bg-slate-900 rounded-[44px] p-3 shadow-2xl border-4 border-slate-700 ring-1 ring-slate-600/50 flex flex-col">
        {/* Device camera punch hole */}
        <div className="absolute top-5 left-1/2 -translate-x-1/2 w-4 h-4 bg-black rounded-full z-50 ring-1 ring-slate-800/80 flex items-center justify-center">
          <div className="w-1.5 h-1.5 rounded-full bg-blue-900/40"></div>
        </div>

        {/* Screen container */}
        <div className="w-full h-full bg-slate-50 rounded-[34px] overflow-hidden flex flex-col relative">
          {/* Android Status Bar */}
          <div className="h-7 bg-slate-900 text-white px-6 flex items-center justify-between text-[11px] font-medium z-40 select-none">
            <span className="tracking-tight font-semibold">{time}</span>
            <div className="flex items-center gap-2 text-slate-300">
              <Signal className="w-3 h-3" />
              <span className="text-[10px] font-bold text-orange-400">4G</span>
              <Wifi className="w-3 h-3" />
              <BatteryMedium className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* App Body */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden relative flex flex-col no-scrollbar">
            {children}
          </div>

          {/* Android Bottom Navigation Pill */}
          <div className="h-3.5 bg-slate-900/95 flex items-center justify-center z-40">
            <div className="w-28 h-1 bg-slate-400/80 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

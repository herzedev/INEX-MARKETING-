import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';
import { INITIAL_USERS } from '../data/initialData';

interface AuthContextType {
  currentUser: UserProfile;
  allUsers: UserProfile[];
  switchUser: (userId: string) => void;
  switchRole: (role: UserRole) => void;
  updateProfile: (updated: Partial<UserProfile>) => void;
  registerUser: (name: string, email: string, phone: string, role: UserRole, shopName?: string) => UserProfile;
  suspendUser: (userId: string, isSuspended: boolean) => void;
  isAuthenticated: boolean;
}

const STORAGE_KEY_USER = 'unex_current_user';
const STORAGE_KEY_ALL_USERS = 'unex_all_users';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [allUsers, setAllUsers] = useState<UserProfile[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ALL_USERS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_USER);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed;
      }
    } catch {
      // fallback
    }
    return INITIAL_USERS[0]; // default: Faly Rakotomalala (buyer)
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ALL_USERS, JSON.stringify(allUsers));
  }, [allUsers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(currentUser));
  }, [currentUser]);

  const switchUser = (userId: string) => {
    const target = allUsers.find(u => u.id === userId);
    if (target) {
      setCurrentUser(target);
    }
  };

  const switchRole = (role: UserRole) => {
    // If switching to seller, pick seller user or convert current
    const matching = allUsers.find(u => u.role === role);
    if (matching) {
      setCurrentUser(matching);
    } else {
      const updated: UserProfile = {
        ...currentUser,
        role,
        shopName: role === 'seller' ? `${currentUser.name} Boutique` : undefined,
        isVerifiedSeller: role === 'seller' ? true : undefined
      };
      setCurrentUser(updated);
      setAllUsers(prev => prev.map(u => u.id === updated.id ? updated : u));
    }
  };

  const updateProfile = (updated: Partial<UserProfile>) => {
    const newUser = { ...currentUser, ...updated };
    setCurrentUser(newUser);
    setAllUsers(prev => prev.map(u => u.id === newUser.id ? newUser : u));
  };

  const registerUser = (
    name: string,
    email: string,
    phone: string,
    role: UserRole,
    shopName?: string
  ): UserProfile => {
    const newUser: UserProfile = {
      id: `user_${Date.now()}`,
      name,
      email,
      phone,
      whatsapp: phone.replace(/[^0-9]/g, ''),
      role,
      city: 'Antananarivo (Renivohitra)',
      shopName: role === 'seller' ? (shopName || `${name} Store`) : undefined,
      isVerifiedSeller: role === 'seller',
      createdAt: new Date().toISOString()
    };
    setAllUsers(prev => [newUser, ...prev]);
    setCurrentUser(newUser);
    return newUser;
  };

  const suspendUser = (userId: string, isSuspended: boolean) => {
    setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, isSuspended } : u));
    if (currentUser.id === userId) {
      setCurrentUser(prev => ({ ...prev, isSuspended }));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        allUsers,
        switchUser,
        switchRole,
        updateProfile,
        registerUser,
        suspendUser,
        isAuthenticated: true
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};

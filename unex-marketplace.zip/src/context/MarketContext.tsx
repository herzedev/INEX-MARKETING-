import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { Product, Order, OrderStatus, ProductCategory, ChatMessage, Conversation, CartItem } from '../types';
import { INITIAL_PRODUCTS, INITIAL_ORDERS } from '../data/initialData';
import { useAuth } from './AuthContext';

interface FilterState {
  searchQuery: string;
  category: ProductCategory | 'all';
  minPrice: number;
  maxPrice: number;
  inStockOnly: boolean;
  city: string;
  sortBy: 'featured' | 'price_asc' | 'price_desc' | 'rating' | 'newest';
}

interface MarketContextType {
  products: Product[];
  filteredProducts: Product[];
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;
  // Product CRUD
  addProduct: (product: Omit<Product, 'id' | 'createdAt' | 'rating' | 'reviewsCount'>) => Product;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  moderateProduct: (id: string, status: 'active' | 'rejected') => void;
  // Orders
  orders: Order[];
  createOrder: (
    items: CartItem[],
    buyerInfo: {
      name: string;
      phone: string;
      city: string;
      address: string;
      notes?: string;
      paymentMethod: 'cod' | 'mvola' | 'orange_money' | 'airtel_money';
    },
    totalAmount: number,
    deliveryFee: number
  ) => Order;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  userOrders: Order[];
  sellerOrders: Order[];
  // Messaging
  conversations: Conversation[];
  messages: ChatMessage[];
  sendMessage: (recipientId: string, recipientName: string, text: string, product?: Product) => void;
  activeChatTarget: { id: string; name: string; product?: Product } | null;
  openChat: (targetId: string, targetName: string, product?: Product) => void;
  closeChat: () => void;
  // UI triggers
  selectedProductForDetail: Product | null;
  setSelectedProductForDetail: (p: Product | null) => void;
}

const STORAGE_KEY_PRODUCTS = 'unex_products';
const STORAGE_KEY_ORDERS = 'unex_orders';
const STORAGE_KEY_MESSAGES = 'unex_messages';
const STORAGE_KEY_CONVS = 'unex_conversations';

const initialFilters: FilterState = {
  searchQuery: '',
  category: 'all',
  minPrice: 0,
  maxPrice: 3000000,
  inStockOnly: false,
  city: 'all',
  sortBy: 'featured'
};

const MarketContext = createContext<MarketContextType | undefined>(undefined);

export const MarketProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PRODUCTS);
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ORDERS);
      return saved ? JSON.parse(saved) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CONVS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MESSAGES);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [filters, setFilters] = useState<FilterState>(initialFilters);
  const [selectedProductForDetail, setSelectedProductForDetail] = useState<Product | null>(null);
  const [activeChatTarget, setActiveChatTarget] = useState<{ id: string; name: string; product?: Product } | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_CONVS, JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_MESSAGES, JSON.stringify(messages));
  }, [messages]);

  const resetFilters = () => setFilters(initialFilters);

  // Filtered Products computation
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      // Must be active (or pending if seller viewing own)
      if (product.status === 'rejected') return false;
      if (product.status === 'pending' && currentUser.role !== 'admin' && currentUser.id !== product.sellerId) {
        return false;
      }

      // Search query (title, description, sellerName, city)
      if (filters.searchQuery.trim()) {
        const q = filters.searchQuery.toLowerCase();
        const matchesTitle = product.title.toLowerCase().includes(q);
        const matchesDesc = product.description.toLowerCase().includes(q);
        const matchesSeller = product.sellerName.toLowerCase().includes(q);
        const matchesCategory = product.category.toLowerCase().includes(q);
        if (!matchesTitle && !matchesDesc && !matchesSeller && !matchesCategory) {
          return false;
        }
      }

      // Category
      if (filters.category !== 'all' && product.category !== filters.category) {
        return false;
      }

      // Price range
      if (product.price < filters.minPrice) return false;
      if (filters.maxPrice < 3000000 && product.price > filters.maxPrice) return false;

      // Stock
      if (filters.inStockOnly && product.stock <= 0) return false;

      // City
      if (filters.city !== 'all' && !product.sellerCity.toLowerCase().includes(filters.city.toLowerCase())) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      switch (filters.sortBy) {
        case 'price_asc':
          return a.price - b.price;
        case 'price_desc':
          return b.price - a.price;
        case 'rating':
          return b.rating - a.rating;
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'featured':
        default:
          return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
      }
    });
  }, [products, filters, currentUser]);

  // Product CRUD
  const addProduct = (
    data: Omit<Product, 'id' | 'createdAt' | 'rating' | 'reviewsCount'>
  ): Product => {
    const newProduct: Product = {
      ...data,
      id: `prod_${Date.now()}`,
      rating: 5.0,
      reviewsCount: 1,
      createdAt: new Date().toISOString()
    };
    setProducts(prev => [newProduct, ...prev]);
    return newProduct;
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const moderateProduct = (id: string, status: 'active' | 'rejected') => {
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, status } : p))
    );
  };

  // Orders
  const createOrder = (
    items: CartItem[],
    buyerInfo: {
      name: string;
      phone: string;
      city: string;
      address: string;
      notes?: string;
      paymentMethod: 'cod' | 'mvola' | 'orange_money' | 'airtel_money';
    },
    totalAmount: number,
    deliveryFee: number
  ): Order => {
    // 1. Deduct stock from products
    setProducts(prev =>
      prev.map(p => {
        const item = items.find(i => i.product.id === p.id);
        if (item) {
          return { ...p, stock: Math.max(0, p.stock - item.quantity) };
        }
        return p;
      })
    );

    const orderItems = items.map(i => ({
      productId: i.product.id,
      title: i.product.title,
      price: i.product.price,
      quantity: i.quantity,
      image: i.product.images[0] || '',
      sellerId: i.product.sellerId
    }));

    const sellerIds = Array.from(new Set(items.map(i => i.product.sellerId)));

    const newOrder: Order = {
      id: `CMD-UNEX-${Math.floor(1000 + Math.random() * 9000)}`,
      buyerId: currentUser.id,
      buyerName: buyerInfo.name,
      buyerPhone: buyerInfo.phone,
      buyerCity: buyerInfo.city,
      deliveryAddress: buyerInfo.address,
      notes: buyerInfo.notes,
      items: orderItems,
      totalAmount,
      deliveryFee,
      paymentMethod: buyerInfo.paymentMethod,
      status: 'pending',
      sellerIds,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setOrders(prev => [newOrder, ...prev]);
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders(prev =>
      prev.map(o =>
        o.id === orderId
          ? { ...o, status, updatedAt: new Date().toISOString() }
          : o
      )
    );
  };

  const userOrders = useMemo(() => {
    return orders.filter(o => o.buyerId === currentUser.id);
  }, [orders, currentUser.id]);

  const sellerOrders = useMemo(() => {
    return orders.filter(o => o.sellerIds.includes(currentUser.id));
  }, [orders, currentUser.id]);

  // Messaging & Chat
  const openChat = (targetId: string, targetName: string, product?: Product) => {
    setActiveChatTarget({ id: targetId, name: targetName, product });
  };

  const closeChat = () => {
    setActiveChatTarget(null);
  };

  const sendMessage = (
    recipientId: string,
    recipientName: string,
    text: string,
    product?: Product
  ) => {
    const convId = [currentUser.id, recipientId].sort().join('__');
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      conversationId: convId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      text,
      productId: product?.id,
      productTitle: product?.title,
      productPrice: product?.price,
      productImage: product?.images[0],
      timestamp: new Date().toISOString(),
      read: false
    };

    setMessages(prev => [...prev, newMsg]);

    setConversations(prev => {
      const existing = prev.find(c => c.id === convId);
      if (existing) {
        return prev.map(c =>
          c.id === convId
            ? {
                ...c,
                lastMessage: text,
                lastTimestamp: new Date().toISOString()
              }
            : c
        );
      }
      return [
        {
          id: convId,
          buyerId: currentUser.role === 'seller' ? recipientId : currentUser.id,
          buyerName: currentUser.role === 'seller' ? recipientName : currentUser.name,
          sellerId: currentUser.role === 'seller' ? currentUser.id : recipientId,
          sellerName: currentUser.role === 'seller' ? currentUser.name : recipientName,
          lastMessage: text,
          lastTimestamp: new Date().toISOString(),
          productId: product?.id,
          productTitle: product?.title,
          productImage: product?.images[0],
          unreadCountBuyer: 0,
          unreadCountSeller: 0
        },
        ...prev
      ];
    });
  };

  return (
    <MarketContext.Provider
      value={{
        products,
        filteredProducts,
        filters,
        setFilters,
        resetFilters,
        addProduct,
        updateProduct,
        deleteProduct,
        moderateProduct,
        orders,
        createOrder,
        updateOrderStatus,
        userOrders,
        sellerOrders,
        conversations,
        messages,
        sendMessage,
        activeChatTarget,
        openChat,
        closeChat,
        selectedProductForDetail,
        setSelectedProductForDetail
      }}
    >
      {children}
    </MarketContext.Provider>
  );
};

export const useMarket = () => {
  const ctx = useContext(MarketContext);
  if (!ctx) throw new Error('useMarket must be used within a MarketProvider');
  return ctx;
};
